-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 10, 2020 at 09:36 PM
-- Server version: 5.7.30
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newskata_dr`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `ID` bigint(20) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `A_Mobile_No` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `DateAndTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`ID`, `Name`, `Email`, `A_Mobile_No`, `Password`, `DateAndTime`, `Status`) VALUES
(1, 'Dibakar Mandal', 'dibakarmandal87@gmail.com', '8116312433', 'D191', '2020-04-20 13:37:48', 'Active'),
(2, 'Ankit', 'ankitgoutam20@gmail.com', '7611984542', 'admin@321', '2020-05-19 16:16:53', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `ID` bigint(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `photo` varchar(40) NOT NULL,
  `specialists` text NOT NULL,
  `hospital_clinic_name` text NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `full_address` text NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `Assign_Doctors` bigint(20) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`ID`, `name`, `photo`, `specialists`, `hospital_clinic_name`, `mobile_no`, `full_address`, `city`, `state`, `Assign_Doctors`, `date_time`, `status`) VALUES
(1, 'Dibakar Mandal', '2020-07-05-13-58-20.jpg', 'developer', 'Hospital Clinic Name test', '8116312433', 'Raghunathganj', 'RNG', 'WB', 0, '2020-07-05 08:28:20', 'Active'),
(2, 'Developer1 webeyesoft1', '2020-07-06-09-27-25.png', 'Specialists in developer', 'Hospital Clinic Name test', '0000000001', 'Addres2', 'Subrub1', 'VIC', 0, '2020-07-06 03:57:25', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `medicals`
--

CREATE TABLE `medicals` (
  `ID` bigint(20) NOT NULL,
  `Name_of_Medical` text NOT NULL,
  `Owner_Name` text NOT NULL,
  `License_No` text NOT NULL,
  `Near_Hostpital_Clinic` text NOT NULL,
  `Address` text NOT NULL,
  `City` text NOT NULL,
  `Mobile_No` varchar(15) NOT NULL,
  `Email_ID` text NOT NULL,
  `Status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicals`
--

INSERT INTO `medicals` (`ID`, `Name_of_Medical`, `Owner_Name`, `License_No`, `Near_Hostpital_Clinic`, `Address`, `City`, `Mobile_No`, `Email_ID`, `Status`) VALUES
(1, 'Dibakar mandal', 'mkay Owner Name', 'sadca34wdsa43dasd32', 'dfdf', 'Vill: Bahadinagar.', 'Raghunathganj', '8116312433', 'seo@webeyesoft.com', 'Active'),
(2, 'Om Medical Cl', 'Om Day', 'sadca34wdsa43dasd324', 'dfdfdsdfdsfsdfsdfdsf', 'bahadinagar, Po+ps: Raghunathganj', 'Raghunathganj', '8509798631', 'sudhakar93@gmail.com', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `ID` bigint(20) NOT NULL,
  `OrderID` bigint(20) NOT NULL,
  `ProductID` bigint(20) NOT NULL,
  `MRP` decimal(18,2) NOT NULL,
  `Quantity` varchar(25) NOT NULL,
  `Amount` decimal(18,2) NOT NULL,
  `Point` decimal(18,2) NOT NULL,
  `Status` varchar(15) NOT NULL,
  `transactionID` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`ID`, `OrderID`, `ProductID`, `MRP`, `Quantity`, `Amount`, `Point`, `Status`, `transactionID`) VALUES
(1, 1, 1, 100.00, '5', 500.00, 150.00, 'Active', ''),
(2, 1, 2, 100.00, '5', 500.00, 200.00, 'Active', ''),
(3, 1, 3, 200.00, '6', 1200.00, 300.00, 'Active', ''),
(4, 1, 3, 200.00, '4', 800.00, 200.00, 'Active', ''),
(5, 1, 5, 400.00, '6', 2400.00, 120.00, 'Active', '');

-- --------------------------------------------------------

--
-- Table structure for table `order_master`
--

CREATE TABLE `order_master` (
  `ID` bigint(20) NOT NULL,
  `Doctor_ID` bigint(20) NOT NULL,
  `Medical_ID` bigint(20) NOT NULL,
  `Order_Date` date NOT NULL,
  `Status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_master`
--

INSERT INTO `order_master` (`ID`, `Doctor_ID`, `Medical_ID`, `Order_Date`, `Status`) VALUES
(1, 1, 2, '2020-07-08', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ID` int(11) NOT NULL,
  `NAME_OF_THE_PRODUCT` text NOT NULL,
  `FULL_DETAILS` text NOT NULL,
  `PRICE` decimal(18,2) NOT NULL,
  `MRP` decimal(18,2) NOT NULL,
  `Point_isPercentage` varchar(10) NOT NULL,
  `Mphoto` varchar(70) NOT NULL,
  `Status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ID`, `NAME_OF_THE_PRODUCT`, `FULL_DETAILS`, `PRICE`, `MRP`, `Point_isPercentage`, `Mphoto`, `Status`) VALUES
(1, 'xcd', 'Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.', 100.00, 100.00, '30', '2020-07-06-09-31-10.png', 'Active'),
(2, 'test1', 'Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.', 100.00, 100.00, '40', '2020-07-08-12-05-31.jpg', 'Active'),
(3, 'test2', 'Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.', 200.00, 200.00, '50', '2020-07-08-12-06-04.jpg', 'Active'),
(4, 'test3', 'Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.', 300.00, 300.00, '5', '2020-07-08-12-06-22.jpg', 'Active'),
(5, 'test4', 'Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.', 400.00, 400.00, '20', '2020-07-08-12-06-52.jpg', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `ID` bigint(20) NOT NULL,
  `Doctor_ID` bigint(20) NOT NULL,
  `Amount` decimal(18,2) NOT NULL,
  `Transaction_ID` text NOT NULL,
  `Remakes` text NOT NULL,
  `Transaction_Type` varchar(15) NOT NULL,
  `Transaction_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`ID`, `Doctor_ID`, `Amount`, `Transaction_ID`, `Remakes`, `Transaction_Type`, `Transaction_Date`) VALUES
(1, 1, 10.00, '34ddsq 413', 'dsasxzcadca', 'Debit', '2020-07-09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `medicals`
--
ALTER TABLE `medicals`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `order_master`
--
ALTER TABLE `order_master`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `medicals`
--
ALTER TABLE `medicals`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_master`
--
ALTER TABLE `order_master`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
