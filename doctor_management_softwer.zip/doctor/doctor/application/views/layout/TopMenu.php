

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo base_url(); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3"><?php if(($this->session->userdata("AID")!="")&&($this->session->userdata("Type")=="Admin")){?>ADMIN<?php }else{?>Dr.<?php }?>PANEL</div>
      </a>
	
      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
<?php if(($this->session->userdata("DRID")!="")&&($this->session->userdata("Type")=="Doctor")){?>
 <!-- Nav Item -  doctor -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/my_profile">
        <i class="fas fa-user"></i>
          <span>My Profile </span></a>		  
      </li>
	 
	 <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/doctor_medicals">
		<i class="fas fa-clinic-medical"></i>
          <span>Medicals</span></a>
      </li>

	  <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/my_points">
		<i class="fas fa-coins"></i></i>
          <span>My Points</span></a>
      </li>
	  
	   <!-- Nav Item - PRODUCTS -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/doctor_products">
		<i class="fab fa-product-hunt"></i>
          <span>Products</span></a>
      </li>
	

<?php } ?>
<?php if(($this->session->userdata("AID")!="" )&&($this->session->userdata("Type")=="Admin")){?>
      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Interface
      </div>
	
	 <!-- Nav Item - Doctor -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/doctor">
        <i class="fas fa-user-plus"></i>
          <span>Add Doctor</span></a>
      </li>

	  <!-- Nav Item - Doctor List -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/doctor_list">
		<i class="fas fa-list-ol"></i>
          <span>List of Doctor</span></a>
      </li>
	  
	
	  <!-- Nav Item - Add Medicals -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/medicals">
		<i class="fas fa-clinic-medical"></i>
          <span>Add Medicals</span></a>
      </li>

	  <!-- Nav Item - List of medicals -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/medicals_list">
		<i class="fas fa-list-ul"></i>
          <span>List of Medicals</span></a>
      </li>

	  <!-- Nav Item - Add Stockist -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/stockist">
		<i class="fas fa-boxes"></i>
          <span>Add Stockist</span></a>
      </li>

	  <!-- Nav Item - All stockist  -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/stockist_list">
		<i class="fas fa-list"></i>
          <span>List of Stockist</span></a>
      </li>
	  
	  <!-- Nav Item - Add PRODUCTS -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/products">
		<i class="fab fa-product-hunt"></i>
          <span>Add Products</span></a>
      </li>

	  <!-- Nav Item - All Products  -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/products_list">
		<i class="fas fa-list"></i>
          <span>List of Products</span></a>
      </li>
	  <!-- Nav Item - All shipment  -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>dashboard/gift">
		<i class="fas fa-gifts"></i>
          <span>Gift Details Page</span></a>
      </li>
	<?php } ?>
      <!-- Nav Item - Pages Collapse Menu -->
    <!--  <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-cog"></i>
          <span>Components</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Custom Components:</h6>
            <a class="collapse-item" href="buttons.html">Buttons</a>
            <a class="collapse-item" href="cards.html">Cards</a>
          </div>
        </div>
      </li>-->

      <!-- Nav Item - Utilities Collapse Menu -->
     <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-fw fa-wrench"></i>
          <span>Utilities</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Custom Utilities:</h6>
            <a class="collapse-item" href="utilities-color.html">Colors</a>
            <a class="collapse-item" href="utilities-border.html">Borders</a>
            <a class="collapse-item" href="utilities-animation.html">Animations</a>
            <a class="collapse-item" href="utilities-other.html">Other</a>
          </div>
        </div>
      </li>-->

      <!-- Divider -->
    <!--  <hr class="sidebar-divider">-->

      <!-- Heading -->
      <!--<div class="sidebar-heading">
        Addons
      </div>-->

      <!-- Nav Item - Pages Collapse Menu -->
      <!--<li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Login Screens:</h6>
            <a class="collapse-item" href="login.html">Login</a>
            <a class="collapse-item" href="register.html">Register</a>
            <a class="collapse-item" href="forgot-password.html">Forgot Password</a>
            <div class="collapse-divider"></div>
            <h6 class="collapse-header">Other Pages:</h6>
            <a class="collapse-item" href="404.html">404 Page</a>
            <a class="collapse-item" href="blank.html">Blank Page</a>
          </div>
        </div>
      </li>-->

      <!-- Nav Item - Charts -->
      <!--<li class="nav-item">
        <a class="nav-link" href="charts.html">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Charts</span></a>
      </li>-->

      <!-- Nav Item - Tables -->
    <!--  <li class="nav-item">
        <a class="nav-link" href="tables.html">
          <i class="fas fa-fw fa-table"></i>
          <span>Tables</span></a>
      </li>-->

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>		
			<?php if($this->session->userdata("Type")=="Doctor"){ if($this->session->userdata("Doctor_photo")==""){ ?>	
				
                <img class="img-profile rounded-circle dp" style="height: 3rem;width: 3rem;" src="https://source.unsplash.com/QAB-WJcbgJk/60x60"> 
				<?php }else{ ?>  
                <img class="img-profile rounded-circle dp" style="height: 3rem;width: 3rem;" src="<?php echo base_url();?>assets/img/doctor/<?php echo $this->session->userdata("Doctor_photo") ?>"> 
				<?php } ?>  
				
				
				<h3 class="dp" style="font-size:2vw; color:blue;"><?php echo $this->session->userdata("Name"); ?></h3>
             
			<?php } ?>  
		
          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
             <!-- <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>-->
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                   <!--  <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div> -->
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1">
             <!-- <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>                
                <span class="badge badge-danger badge-counter">3+</span>
              </a>-->
              <!-- Dropdown - Alerts -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                  Alerts Center
                </h6>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-primary">
                      <i class="fas fa-file-alt text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 12, 2019</div>
                    <span class="font-weight-bold">A new monthly report is ready to download!</span>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-success">
                      <i class="fas fa-donate text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 7, 2019</div>
                    $290.29 has been deposited into your account!
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-warning">
                      <i class="fas fa-exclamation-triangle text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 2, 2019</div>
                    Spending Alert: We've noticed unusually high spending for your account.
                  </div>
                </a>
                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
              </div>
            </li>

            <!-- Nav Item - Messages -->
            <li class="nav-item dropdown no-arrow mx-1" >
			<?php if(($this->session->userdata("Type")=="delivery_boy")&&($this->session->userdata("AID")!="" )){ ?>
						
             <a class="nav-link" href="<?php echo base_url();?>login/logout_admin_for_db" style="color: #4d72de;" alt="Admin " title="Back to admin"><i class="fas fa-user-cog"></i> Admin</a>
			 <?php } ?>
            </li>

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
					
				</span>
				<?php if($this->session->userdata("Type")=="Admin"){ ?>
						<img class="img-profile rounded-circle" src="https://source.unsplash.com/QAB-WJcbgJk/60x60">
				<?php }else{ ?>
						<i class="fas fa-wallet fa-2x" style="color:blue;"></i>
				<?php } ?> 
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
			  <?php if($this->session->userdata("Type")=="Doctor"){ ?>
                <a class="dropdown-item" href="<?php echo base_url();?>dashboard/my_points">
                  <i class="fas fa-coins mr-2 text-gray-400"></i>				  
                  My Points
                </a>
				<?php } ?>
                <!---<a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>-->
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
<div class="container-fluid">
