<?php
include("header_link.php");
//============= Top Menu ==
include("TopMenu.php"); 
//====== Msg Box ===
include("msgbox.php"); 
$this->load->view($page);

include("footer.php"); 
?>