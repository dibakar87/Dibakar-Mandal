<?php if($this->session->flashdata('SMSG')!="" or $this->session->flashdata('FMSG')!=""){ ?>	
	<div class="col-sm-12">
		<?php if($this->session->flashdata('SMSG')!=""){
			?>
			<div class="alert alert-success">
			  <strong>Success!</strong> <?php echo $this->session->flashdata('SMSG')?>.
			</div>
			<?php 

		} 
		if($this->session->flashdata('FMSG')!=""){
			?>
			<div class="alert alert-danger">
			  <strong>Failed!</strong> <?php echo $this->session->flashdata('FMSG')?>
			</div>
			<?php
		}?>
	
	</div>	
<?php } ?>