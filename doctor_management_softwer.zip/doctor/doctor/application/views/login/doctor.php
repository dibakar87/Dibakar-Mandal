<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $title; ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
   
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url(); ?>assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="<?php echo base_url(); ?>assets/css/sb-admin-2.min.css" rel="stylesheet">
  
  </head>
  <style>
  .bg-delivery-boy-image {
		background: url(<?php echo base_url();?>/assets/img/svg/doctorl.svg);
		background-position: center;
		background-size: cover;
		background-color: #fff;
	} 
	
	.error {
    color: #5a5c69;
    font-size: 2rem;
    position: relative;
    line-height: 1;
    width: 66.5rem;
}
  </style>
  
  <body class="bg-gradient-primary" >
  <?php if($this->session->flashdata('SMSG')!="" or $this->session->flashdata('FMSG')!=""){ ?>
		<div class="container">
			<div class="row">
				<div class="col-sm-4">&nbsp;</div>
					<div class="col-sm-4">
						<?php if($this->session->flashdata('SMSG')!=""){
							?>
							<div class="alert alert-success">
							  <strong>Success!</strong> <?php echo $this->session->flashdata('SMSG')?>.
							</div>
							<?php 

						} 
						if($this->session->flashdata('FMSG')!=""){
							?>
							<div class="alert alert-danger">
							  <strong>Failed!</strong> <?php echo $this->session->flashdata('FMSG')?>
							</div>
							<?php
						}?>
					
					</div>
				 <div class="col-sm-4">&nbsp;</div>
			</div>
		</div>
	<?php } ?>
	
	
 <div class="container">
 <div class="error" ></div>
	<div class="success"></div>
	<div ID="msg" ></div>
 </div>
 <div class="container">
    <!-- Outer Row -->
    <div class="row justify-content-center">
      <div class="col-xl-10 col-lg-12 col-md-9">
        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-6 d-none d-lg-block bg-delivery-boy-image"></div>
              <div class="col-lg-6">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">WELCOME BACK!</h1>
                    <h4 class="h4  mb-4">DOCTOR</h4>
                  </div>
				  <hr>
					<form id="frm-mobile-verification" class="user" >
						
						<div class="form-group">
						   <div class="input-group ">
							<div class="input-group-prepend">
							  <span class="input-group-text">+91</span>
							</div>
							<input type="number" id="mobile" class="form-control " <?php if($_COOKIE[Mobile]!=""){?> value="<?php echo $_COOKIE[Mobile]; ?>"<?php } ?> 	placeholder="Enter the 10 digit mobile">							
						  </div>					  
						</div>
						

						<input type="button" class="btn btn-primary btn-user btn-block" value="Send OTP" onClick="sendOTP();">			
					
					
						<div class="form-group">
								
						</div>

						<div class="form-group">
						  <div class="input-group ">
							<div class="input-group-prepend">
							  <span class="input-group-text">OTP</span>
							</div>
							<input type="number"  id="mobileOtp" class="form-control" placeholder="Enter the OTP">	
								
						  </div>
						</div>
						
						

						<div class="row">
						<?php //echo $session_otp=$this->session->userdata("session_otp"); ?>
						<?php //echo $_COOKIE[Mobile]; ?>
						<?php //echo $_COOKIE[New_User]; ?>
						<input id="verify" type="button" class="btn btn-primary btn-user btn-block" value="login" onClick="verifyOTP();">		
						</div>
						
					</form>
				  
				  
                  <hr>
                  <div class="text-center">
                    <a class="small" href="<?php echo base_url();?>login/chnage">Trouble in login ?<br> Make Request for number chnage</a>
                  </div>                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    <!-- JavaScript files-->
	
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  <!-- Bootstrap core JavaScript-->
	  <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
	  <script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

	  <!-- Core plugin JavaScript-->
	  <script src="<?php echo base_url(); ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>

	  <!-- Custom scripts for all pages-->
	  <script src="<?php echo base_url(); ?>assets/js/sb-admin-2.min.js"></script>
	
  <script>
  
	function sendOTP() {
		$(".error").html("").hide();
		/* $(".success").html("").hide(); */
		var number = $("#mobile").val();
		if (number.length == 10 && number != null) {
			var input = {
				"mobile_number" : number,
				"action" : "send_otp"
			};
			$.ajax({
				url : '<?php echo base_url();?>login/process_mobile_verification',
				type : 'POST',
				data : input,
				success : function(response) {
					$(".success").html('<div style="margin-top: 55px;margin: 22px;text-align: center;" class=" alert alert-success alert-dismissible fade show " role="alert"><strong>Success!</strong> OTP sent Successfully.  <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>');
					$(".success").show();						
								
					//window.location.href='app/index' */
				},
				error : function() {							
					$(".error").html('<div style="margin-top: 55px;margin: 22px;text-align: center;" class="alert alert-danger alert-dismissible fade show" role="alert"><strong>Failed!</strong>Please enter a valid number!  <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>');
					$(".error").show();
				}
			});
		} else {
			$(".error").html('<div style="margin-top: 55px;margin: 22px;text-align: center;" class="alert alert-danger alert-dismissible fade show" role="alert"><strong>Failed!</strong>Please enter a valid number!  <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>');
			$(".error").show();
		}
	}

	function verifyOTP() {
		$(".error").html("").hide();
		$(".success").html("").hide();
		var otp = $("#mobileOtp").val();
		var input = {
			"otp" : otp,
			"action" : "verify_otp"
		};
		if (otp.length == 6 && otp != null) {
			$.ajax({
				url : '<?php echo base_url();?>login/process_mobile_verification',
				type : 'POST',
				dataType : "json",
				data : input,
				success : function(response) {
					 $("." + response.type).html('<div style="margin-top: 55px;margin: 22px;text-align: center;" class=" alert alert-success alert-dismissible fade show " role="alert"><strong>Success!</strong>'+ response.message  +' <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>');
					$("." + response.type).show(); 
					
					//window.location.href='profileinfo'
					IsUserAval(response.mobile);
				},
				error : function() {
					$(".error").html('<div style="margin-top: 55px;margin: 22px;text-align: center;" class="alert alert-danger alert-dismissible fade show" role="alert"><strong>Failed!</strong>You have entered wrong OTP.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>');
					$(".error").show();
				}
			});
		} else {
			$(".error").html('<div style="margin-top: 55px;margin: 22px;text-align: center;" class="alert alert-danger alert-dismissible fade show" role="alert"><strong>Failed!</strong>You have entered wrong OTP.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>');
			$(".error").show();
		} 
	}
	function IsUserAval(mobileNo){
		//alert(mobileNo);
		$.ajax({
				url : '<?php echo base_url();?>login/IsUserAval/'+mobileNo,
				type : 'POST',
				dataType : "json",
				 
				success : function(response) {
					//alert(response.user);
					if(response.user=="yes"){					
						window.location.href='<?php echo base_url(); ?>dashboard'
					}
				},
				error : function() {
					$(".error").html('You have entered wrong OTP.');
					$(".error").show();
				}
			});				
	}
  </script>
	
  </body>
</html> 
