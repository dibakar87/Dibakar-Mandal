  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> /All Products List</h1>	
  </div>
  
  	
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">All Products List!</h6>
            </div>
			
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>S.No</th>
					  <th>Product</th>
                      <th>Details</th>
                      <th>Price</th>
                      <th>Edit & VIEW</th>                                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
					  <th>S.No</th>
					  <th>Product</th>
                      <th>Details</th>
                      <th>Price</th>
                      <th>Edit & VIEW</th>              
                    </tr>
                  </tfoot>
                  <tbody>
				   
					<?php $i=1; foreach($get_products_details as $get_products){ ?>
						<tr>
						  <td>
						  <?php echo $i++ ?></td>						 
						  <td><?php echo $get_products->NAME_OF_THE_PRODUCT; ?> </td>
						  <td><?php echo $get_products->FULL_DETAILS ; ?></td>
						  <td><?php echo $get_products->PRICE; ?></td>
						 <td><a href="<?php echo base_url()?>dashboard/products?ID=<?php echo $get_products->ID; ?>" ><i class="far fa-eye"></i>Edit & VIEW</a></td>
						</tr>										
					<?php } ?>					
                  </tbody>
                </table>
              </div>
            </div>
          </div>

 
      