  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> /All Order Products list</h1>	
  </div>
  
  	
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">All Order Products List!</h6>
            </div>
			
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>S.No</th>
					  <th>Order ID</th>
					  <th>Dr.Name</th>
                      <th>Medical ID</th> 
                      <th>Product</th> 
                      <th>MRP</th> 
                      <th>Quantity</th> 
                      <th>Amount</th> 
                      <th>Point</th> 					  
                      <th>Action</th>                                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
					  <th>S.No</th>
					  <th>Order ID</th>
					  <th>Dr.Name</th>
                      <th>Medical ID</th> 
                      <th>Product</th> 
                      <th>MRP</th> 
                      <th>Quantity</th> 
                      <th>Amount</th> 
                      <th>Point</th> 					  
                      <th>Action</th>               
                    </tr>
                  </tfoot>
                  <tbody>
				   
					<?php $i=1; foreach($get_order_details as $get_doctor_order){ ?>
						<tr>
						  <td>
						  <?php echo $i++ ?></td>						 
						  <td><?php echo $get_doctor_order->OrderID ; ?></td>
						  <td><?php echo $this->input->get("name"); ?> (<?php echo $get_doctor_order->Doctor_ID ; ?>)</td>
						  <td><?php echo $get_doctor_order->Medical_ID ; ?></td>	
						  <td><?php 	
							$sql="select * from products where ID='".$get_doctor_order->ProductID ."' ";	
							$query=$this->db->query($sql);
							$ProductID=$query->row();
						  echo $ProductID->NAME_OF_THE_PRODUCT ; ?></td>	
						  <td><?php echo $get_doctor_order->MRP ; ?></td>	
						  <td><?php echo $get_doctor_order->Quantity ; ?></td>	
						  <td><?php echo $get_doctor_order->Amount ; ?></td>	
						  <td><?php echo $get_doctor_order->Point ; ?></td>						  
						 <td><a href="#" data-toggle="modal" data-target="#productsModal<?php echo$get_doctor_order->ODID; ?>" title="Edit"><i class="fas fa-edit fa-2x"></i></a></td>
						</tr>
						
						 <!--Modal-->
						  <div class="modal fade" id="productsModal<?php echo $get_doctor_order->ODID; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog modal-xl" role="document">
							  <div class="modal-content">
								<div class="modal-header">
								  <h5 class="modal-title" id="exampleModalLabel">Products Edit</h5>
								  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">×</span>
								  </button>
								</div>
								<div class="modal-body">
								
		<form  class="user" onSubmit="return validate();" action="<?php echo base_url(); ?>dashboard/create_order_edit_action" method="post" enctype="multipart/form-data" >
		  <div class="form-group">
		   <div class="col-sm-12 mb-6 ">
			  <label >CHOOSE MEDICAL (FROM DROP-DOWN WHICH ASSIGN TO DOCTOR) </label>				
				<select class="form-control " name="Medical_ID" ID="Medical_ID"  required="required" autofocus="autofocus">
				<option value="" >Select MEDICAL...</option>
				<?php foreach($get_medicals_details as $get_medicals){ ?>
				<option value="<?php echo $get_medicals->ID; ?>" <?php if($get_medicals->ID == $get_doctor_order->Medical_ID ){ echo"selected";} ?>> <?php echo $get_medicals->Name_of_Medical; ?> </option>
				<?php } ?>
				 </select>
			</div>	
			
			
			<input type="hidden" id="DoctorID" name="DoctorID" value="<?php echo $get_doctor_order->Doctor_ID; ?>" >
			<input type="hidden" id="DoctorName" name="DoctorName" value="<?php echo $this->input->get("name"); ?> " >
			<input type="hidden" id="OMID" name="OMID" value="<?php echo $get_doctor_order->OMID; ?>" >
			<input type="hidden" id="ODID" name="ODID" value="<?php echo $get_doctor_order->ODID; ?>" >
			
		 </div>	
			
			
			<div class="form-group row ">
			  <div class="col-sm-3">
				<label >Product</label>					
				<select class="form-control " name="ProductID" ID="ProductID<?php echo $get_doctor_order->ODID; ?>" onChange="productMethod11(<?php echo $get_doctor_order->ODID; ?>)"   required="required" autofocus="autofocus">
				<option value="">Select Product...</option>
				<?php foreach($get_products_details as $get_products){ ?>
				<option value="<?php echo $get_products->ID; ?>"  <?php if($get_products->ID == $get_doctor_order->ProductID ){ echo"selected";} ?> > <?php echo $get_products->NAME_OF_THE_PRODUCT; ?> </option>
				<?php } ?>
				</select>
				
			  </div>
			  
			  <div class="col-sm-2">		
				<label >MRP</label>				
				<input type="number" class="form-control " id="MRP<?php echo $get_doctor_order->ODID; ?>" value="<?php echo $ProductID->MRP ; ?>" name="MRP" placeholder="MRP" readonly >  
			  </div>
			  
			  <div class="col-sm-2">		
				<label >Quantity</label>				
				<input type="number" class="form-control " id="Quantity<?php echo $get_doctor_order->ODID; ?>" value="<?php echo $get_doctor_order->Quantity; ?>" name="Quantity" placeholder="Quantity" onKeyUp="multiply(<?php echo $get_doctor_order->ODID; ?>)" required="required" autofocus="autofocus"  >  
			  </div>
			  <div class="col-sm-2">
				<label >Amount</label>				
				<input type="number" class="form-control " id="Amount<?php echo $get_doctor_order->ODID; ?>" name="Amount" placeholder="Amount (auto)" required="required" autofocus="autofocus" value="<?php echo $get_doctor_order->Amount ; ?>" readonly >
				<input type="text" value="<?php echo $ProductID->PRICE ; ?>" id="Amount_let<?php echo $get_doctor_order->ODID; ?>"  >
			  </div>
			  <div class="col-sm-2">
				<label >Point</label>				
				<input type="number" class="form-control " id="Point<?php echo $get_doctor_order->ODID; ?>" name="Point" placeholder="Point (auto)" required="required" autofocus="autofocus" value="<?php echo $get_doctor_order->Point ; ?>" readonly >
				<input type="text" value="<?php echo $ProductID->Point_isPercentage ; ?>" id="Point_let<?php echo $get_doctor_order->ODID; ?>"  >
			  </div>
			  
			</div>
			
			<div class="col-sm-12" id="moreFiles"></div>
			<div class="line"></div>
			
			<button type="submit"  class="btn btn-primary btn-user "><?php if($this->input->get('ID')!=""){ ?> Update<?php }else{ ?>Save<?php } ?></button>	
			<!--<button type="button" onclick="AddFilesMore()" class="btn btn-success btn-user" >Add More</button>-->
					
		  </form>
								
								</div>
								<div class="modal-footer">
								  <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
								</div>
							  </div>
							</div>
						  </div>
					<?php } ?>					
                  </tbody>
                </table>
              </div>
            </div>
          </div>

 
<script>
 /* 	function AddFilesMore(){
		ss=$("#count").val();
		ss=Number(ss)+1;
		$("#count").val(ss);
		var Str='<div class="form-group row "><div class="col-sm-3"><label >Product</label><select class="form-control " onchange="productMethod11('+ss+')" name="ProductID[]" ID="ProductID'+ss+'"  required="required" autofocus="autofocus"><option value="">Select Product...</option><?php foreach($get_products_details as $get_products){ ?><option value="<?php echo $get_products->ID; ?>"> <?php echo $get_products->NAME_OF_THE_PRODUCT; ?> </option><?php } ?></select></div><div class="col-sm-2"><label >MRP</label><input type="number" class="form-control " id="MRP'+ss+'" name="MRP[]" placeholder="MRP" readonly ></div><div class="col-sm-2"><label >Quantity</label><input type="number" class="form-control " id="Quantity'+ss+'" name="Quantity[]" onKeyUp="multiply('+ss+')" placeholder="Quantity" required="required" autofocus="autofocus"  ></div><div class="col-sm-2"><label >Amount</label><input type="number" class="form-control " id="Amount'+ss+'" name="Amount[]" placeholder="Amount (auto)" required="required" autofocus="autofocus" readonly > <input type="hidden" id="Amount_let'+ss+'"  ></div><div class="col-sm-2"><label >Point</label><input type="number" class="form-control " id="Point'+ss+'" name="Point[]" placeholder="Point (auto)" required="required" autofocus="autofocus" readonly><input type="hidden" id="Point_let'+ss+'"  ></div><button type="button"  title="Remove" class="btn btn-danger" style="margin-top: 32px;"  onclick="del_tr(this)"><i class="far fa-times-circle"></i></button> </div>';
		$("#moreFiles").append(Str);
	}  */
</script>
<input type="hidden" id="count" value="0">
<script>
	/* function del_tr(e){   
 	 e.parentNode.parentNode.removeChild(e.parentNode);
	} */
</script>


<script>
function multiply(ss) {
  a = Number(document.getElementById('Quantity'+ss).value);
  b = Number(document.getElementById('Amount_let'+ss).value);
  c = Number(document.getElementById('Point_let'+ss).value);
  t = a * b;
  p = a * c;

  document.getElementById('Amount'+ss).value = t;
  document.getElementById('Point'+ss).value = p;
}
</script>
<script>
function productMethod11(ss){
	//alert('00');
	product_id=$("#ProductID"+ss).val();	
	 $.ajax({type: 'POST', url: '<?php echo base_url()?>dashboard/get_product_json?product_id='+product_id, dataType: 'json', 
		success: function(data){	

			
			console.log(data.SQL1);	
			$('#NAME_OF_THE_PRODUCT'+ss).val(data.NAME_OF_THE_PRODUCT);
			$('#Amount'+ss).val(data.PRICE);
			$('#Amount_let'+ss).val(data.PRICE);
			$('#MRP'+ss).val(data.MRP);
			$('#Point'+ss).val(data.Point_isPercentage);
			$('#Point_let'+ss).val(data.Point_isPercentage);
			
		}
    });
}
</script>
      