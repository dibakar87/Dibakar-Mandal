  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> / WALLET</h1>	
  </div>
  
    <!-- add-->
	<div class="container">
		
		  <div class="text-center">
			<h1 class="h4 text-gray-900 mb-4" style="background-color: cornflowerblue;" >WALLET</h1>
		  </div>
		  <form  class="user" onSubmit="return validate();" action="<?php echo base_url(); ?>dashboard/wallet_action" method="post" enctype="multipart/form-data" >
		  
			<div class="form-group row">
			  <div class="col-sm-3">
				<label >AMOUNT</label>
				<input type="hidden" id="Doctor_ID" name="Doctor_ID" value="<?php echo $this->input->get("DRID"); ?>" >
				<input type="hidden" id="ID" name="ID" value="<?php echo $transaction->ID; ?>" >
				<input type="number" class="form-control " id="AMOUNT" name="AMOUNT" placeholder="AMOUNT" value="<?php echo $transaction->Amount; ?>" required="required" autofocus="autofocus">
			  </div>
			  <div class="col-sm-1">		
				<label >DEBIT</label>				
				<input type="text" class="form-control " id="type_c_d" name="type_c_d" placeholder="DEBIT" value="Debit" required="required" autofocus="autofocus" readonly >  
			  </div>
			  <div class="col-sm-3">
				<label >Transaction ID</label>				
				<input type="text" class="form-control " id="Transaction_ID" name="Transaction_ID" placeholder="Transaction ID" value="<?php echo $transaction->Transaction_ID; ?>" required="required" autofocus="autofocus" >
			  </div>
			  <div class="col-sm-3">
				<label >REMARK</label>				
				<input type="text" class="form-control " id="REMARK" name="REMARK" placeholder="REMARK" value="<?php echo $transaction->Remakes; ?>" required="required" autofocus="autofocus" >
			  </div>
			 <div class="col-sm-2">
				<label ></label>
				<button type="submit"  class="btn btn-primary btn-user btn-block"><?php if($this->input->get('ID')!=""){ ?> Update<?php }else{ ?>Submit <?php } ?></button>	
			  </div>
			</div>	
			
					
		  </form>		 
		
		
	</div>
	
  	
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
	<div class="card-header py-3">
	  <h6 class="m-0 font-weight-bold text-primary">Doctor Transaction  List!</h6>
	</div>
	
	<div class="card-body">
	  <div class="table-responsive">
		<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
		  <thead>
			<tr>
			  <th>S.No</th>
			  <th>Dr.Name</th>
			  <th>AMOUNT</th>
			  <th>Transaction</th>
			  <th>Remakes</th>
			  <th>Date</th>			                                     
			  <th>Action</th>			                                     
			</tr>
		  </thead>
		  <tfoot>
			<tr>
			  <th>S.No</th>
			  <th>Dr.Name</th>
			  <th>AMOUNT</th>
			  <th>Transaction</th>
			  <th>Remakes</th>
			  <th>Date</th>	
			  <th>Action</th>	
		  </tfoot>
		  <tbody>
		   
			<?php $i=1; foreach($get_transaction_details as $get_transaction){ ?>
				<tr>
				  <td>
				  <?php echo $i++ ?></td>						 
				  <td><?php echo $this->input->get("name"); ?><?php// echo $get_transaction->name; ?> </td>
				  <td><?php echo $get_transaction->Amount ; ?></td>
				  <td><?php echo $get_transaction->Transaction_ID ; ?></td>
				  <td><?php echo $get_transaction->Remakes ; ?></td>
				  <td><?php echo $get_transaction->Transaction_Date ; ?></td>				  
				 <td><a href="<?php echo base_url()?>dashboard/wallet?DRID=<?php echo $get_transaction->Doctor_ID; ?>&name=<?php echo $this->input->get("name"); ?>&ID=<?php echo $get_transaction->ID ; ?>" title="Edit"><i class="fas fa-edit fa-2x"></i></a></td>
				</tr>										
			<?php } ?>					
		  </tbody>
		</table>
	  </div>
	</div>
  </div>

 
      
	
	