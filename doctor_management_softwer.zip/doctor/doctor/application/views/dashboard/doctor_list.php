  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> /All Doctor list</h1>	
  </div>
  
  	
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">All Doctor List!</h6>
            </div>
			
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>S.No</th>
					  <th>Dr.Name</th>
                      <th>MOBILE NO.</th>
                      <th>Wallet</th>
                      <th>Order History</th>
                      <th>Create Order</th>
                      <th>Edit & VIEW ALL DETAILS</th>                                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
					  <th>S.No</th>
					  <th>Dr.Name</th>
                      <th>MOBILE NO.</th>
                      <th>Wallet</th>
                      <th>Order History</th>
                      <th>Create Order</th>
                      <th>Edit & VIEW ALL DETAILS</th>              
                    </tr>
                  </tfoot>
                  <tbody>
				   
					<?php $i=1; foreach($get_doctor_details as $get_doctor){ ?>
						<tr>
						  <td>
						  <?php echo $i++ ?></td>						 
						  <td><?php echo $get_doctor->name; ?> </td>
						  <td><?php echo $get_doctor->mobile_no ; ?></td>
						  <td><a href="<?php echo base_url(); ?>dashboard/wallet?DRID=<?php echo $get_doctor->ID; ?>&name=<?php echo $get_doctor->name; ?>" title="Credit/Debit"><i class="fas fa-wallet fa-2x "></i></a></td>
						  
						  <td><a href="<?php echo base_url(); ?>dashboard/order_history?DRID=<?php echo $get_doctor->ID; ?>&name=<?php echo $get_doctor->name; ?>" title="Order History">All Orders</a></td>
						  
						  <td><a href="<?php echo base_url(); ?>dashboard/create_order?DRID=<?php echo $get_doctor->ID; ?>&name=<?php echo $get_doctor->name; ?>" title="Create Orders">Create Order</a></td>
						  
						 <td><a href="<?php echo base_url()?>dashboard/doctor?DRID=<?php echo $get_doctor->ID; ?>" title="Edit & VIEW"><i class="far fa-eye fa-2x"></i></a></td>
						</tr>										
					<?php } ?>					
                  </tbody>
                </table>
              </div>
            </div>
          </div>

 
      