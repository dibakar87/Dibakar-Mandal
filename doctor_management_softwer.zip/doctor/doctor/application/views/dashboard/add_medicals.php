  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> / Medicals</h1>	
  </div>
  
    <!-- add-->
	<div class="container">
		
		  <div class="text-center">
			<h1 class="h4 text-gray-900 mb-4" style="background-color: cornflowerblue;" >Add Medicals!</h1>
		  </div>
		  <form  class="user" onSubmit="return validate();" action="<?php echo base_url(); ?>dashboard/medicals_action" method="post" enctype="multipart/form-data" >
		  
		  
			<div class="form-group row">
			  <div class="col-sm-6 mb-3 mb-sm-0">
				<label >Name of Medical</label>
				<input type="text" class="form-control " ID="Name_of_Medical" Name="Name_of_Medical"  placeholder="Name of Medical" value="<?php echo $get_medicals->Name_of_Medical; ?>" required="required"  autofocus="autofocus" >
				
			  </div>
			  <div class="col-sm-6">
				<label >Owner Name</label>
				<input type="hidden" id="ID" name="ID" value="<?php echo $get_medicals->ID; ?>" >
				<input type="text" class="form-control " id="Owner_Name" name="Owner_Name" placeholder="Owner Name" value="<?php echo $get_medicals->Owner_Name; ?>" required="required" autofocus="autofocus" >
			  </div>
			</div>
			
			<!-- sudhakar -->
			<div class="form-group">
				<label>License No.</label>
			  <input type="text" class="form-control " id="License_No" name="License_No" placeholder="License No." value="<?php echo $get_medicals->License_No; ?>" required="required" autofocus="autofocus" >
			</div>
			<div class="form-group">
				<label>Near Hostpital/Clinic</label>
			  <input type="text" class="form-control " id="Near_Hostpital_Clinic" name="Near_Hostpital_Clinic" placeholder="Near Hostpital/Clinic" value="<?php echo $get_medicals->Near_Hostpital_Clinic; ?>" required="required" autofocus="autofocus" >
			</div>
			
			<div class="form-group">
				<label>Address</label>
			  <input type="text" class="form-control " id="Address" name="Address" placeholder="Address" value="<?php echo $get_medicals->Address; ?>" required="required" autofocus="autofocus" >
			</div>
			
			
			
			<div class="form-group row">
			  <div class="col-sm-6 mb-3 mb-sm-0">
				<label >City</label>
				<input type="text" class="form-control " id="City" name="City" value="<?php echo $get_medicals->City; ?>" placeholder="City" required="required" autofocus="autofocus" >
			  </div>
			  <div class="col-sm-6">
				<label >Mobile No.</label>
				<input type="number" class="form-control " id="Mobile_No" name="Mobile_No" value="<?php echo $get_medicals->Mobile_No; ?>" placeholder="Mobile No." required="required" autofocus="autofocus" >
			  </div>
			</div>
			
			<div class="form-group row">
			  <div class="col-sm-6 mb-3 mb-sm-0">
				<label >Email ID</label>
				<input type="email" class="form-control " id="Email_ID" name="Email_ID" value="<?php echo $get_medicals->Email_ID; ?>" placeholder="Email ID" required="required" autofocus="autofocus" >
			  </div>
			  <div class="col-sm-6">
				
			  </div>
			</div>
			
			
			<button type="submit"  class="btn btn-primary btn-user btn-block"><?php if($this->input->get('ID')!=""){ ?> Update<?php }else{ ?>Submit <?php } ?></button>	
					
		  </form>		 
		
	</div>
	
<script>
  var loadFile = function(event){
	  document.getElementById('viewimg').src = URL.createObjectURL(event.target.files[0]);  
  };
</script>