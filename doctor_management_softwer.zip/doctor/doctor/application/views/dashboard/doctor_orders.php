  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> /Products Orders List</h1>	
  </div>
  
  	
          <!-- DataTales Example -->
          <!--<div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary"> Products Orders List!</h6>
            </div>
			
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>S.No</th>					 
                      <th>Details</th>
                      <th>Amount</th>
                      <th>Points</th>
                      <th>Date</th>                                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
					  <th>S.No</th>					  
                      <th>Details</th>
                      <th>Amount</th>
                      <th>Points</th>
                      <th>Date</th>             
                    </tr>
                  </tfoot>
                  <tbody>
				   
					<?php $i=1; foreach($get_products_details as $get_products){ ?>
						<tr>
						  <td>
						  <?php echo $i++ ?></td>						 
						  <?php echo $get_products->NAME_OF_THE_PRODUCT; ?> </td>
						  <td><a href="#" data-toggle="modal" data-target="#products<?php echo $get_products->ID; ?>"><?php echo $get_products->FULL_DETAILS ; ?></a></td>
						  <td><?php echo $get_products->PRICE; ?></td>
						  <td>কন পয়েন্ট</td>
						 <td>তারিখ</td>
						</tr>



						
						  <div class="modal fade" id="products<?php echo $get_products->ID; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
							  <div class="modal-content">
								<div class="modal-header">
								  <h5 class="modal-title" id="exampleModalLabel">Products Details</h5>
								  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">×</span>
								  </button>
								</div>
								<div class="modal-body">
									<?php echo $get_products->NAME_OF_THE_PRODUCT; ?> 
								</div>
								<div class="modal-footer">
								  <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
								</div>
							  </div>
							</div>
						  </div>	
					<?php } ?>					
                  </tbody>
                </table>
              </div>
            </div>
          </div>-->

 
       <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">All Order and Products List!</h6>
            </div>
			
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>S.No</th>
					  <th>Order ID</th>
					  <th>Dr.Name</th>
                      <th>Medical ID</th> 
                      <th>Product</th> 
                      <th>MRP</th> 
                      <th>Quantity</th> 
                      <th>Amount</th> 
                      <th>Point</th> 					  
                      <th>Date</th> 					  
                      <!--<th>Action</th> -->                                     
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
					  <th>S.No</th>
					  <th>Order ID</th>
					  <th>Dr.Name</th>
                      <th>Medical ID</th> 
                      <th>Product</th> 
                      <th>MRP</th> 
                      <th>Quantity</th> 
                      <th>Amount</th> 
                      <th>Point</th> 					  
                      <th>Date</th> 					  
                      <!--<th>Action</th>  -->             
                    </tr>
                  </tfoot>
                  <tbody>
				   
					<?php $i=1; foreach($get_medicals_and_doc_order_details as $get_doctor_order){ ?>
						<tr>
						  <td>
						  <?php echo $i++ ?></td>						 
						  <td><?php echo $get_doctor_order->OrderID ; ?></td>
						  <td><?php echo $this->session->userdata("Name"); ?> (<?php echo $get_doctor_order->Doctor_ID ; ?>)</td>
						  <td><?php
							$sql="select Name_of_Medical from medicals where ID='".$get_doctor_order->Medical_ID ."' ";	
							$query=$this->db->query($sql);
							$Medical_name=$query->row();

						  echo $Medical_name->Name_of_Medical ; ?></td>	
						  <td><?php 	
							$sql="select * from products where ID='".$get_doctor_order->ProductID ."' ";	
							$query=$this->db->query($sql);
							$ProductID=$query->row();?>
						 <a href="#" data-toggle="modal" data-target="#productsModalL<?php echo $get_doctor_order->ProductID; ?>" title="View"><?php echo $ProductID->NAME_OF_THE_PRODUCT ; ?></a></td>	
						  <td><?php echo $get_doctor_order->MRP ; ?></td>	
						  <td><?php echo $get_doctor_order->Quantity ; ?></td>	
						  <td><?php echo $get_doctor_order->Amount ; ?></td>	
						  <td><?php echo $get_doctor_order->Point ; ?></td>						  
						  <td><?php echo $get_doctor_order->Order_Date ; ?></td>						  
						 <!--<td><a href="#" data-toggle="modal" data-target="#products11111<?php echo $get_doctor_order->ProductID; ?>" title="Edit"><i class="fas fa-edit fa-2x"></i></a></td>-->
						</tr>	


						
						  <div class="modal fade" id="productsModalL<?php echo $get_doctor_order->ProductID; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
							  <div class="modal-content">
								<div class="modal-header">
								  <h5 class="modal-title" id="exampleModalLabel">Products Details</h5>
								  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">×</span>
								  </button>
								</div>
								<div class="modal-body">
									<div class="col-sm-12"><b>NAME OF THE PRODUCT: <span style="color:red"><?php echo $ProductID->NAME_OF_THE_PRODUCT; ?></span></b></div><hr>	
									<div class="row">									
										<div class="col-sm-6">
											<img  id="viewimg" src="<?php echo base_url();?>assets/img/Product/<?php echo $ProductID->Mphoto ?>" alt="Image Preview" style="height: 150px;"  ><hr>
											<div class="col-sm-12"><b>PRICE:<span style="color:red"><?php echo $ProductID->PRICE; ?></span></b></div><hr>
										</div>	
										<div class="col-sm-6">
											<b>PRODUCTS DETAILS<br><?php echo $ProductID->FULL_DETAILS; ?></b>
										</div>	
									</div>
									
								</div>
								<div class="modal-footer">
								  <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
								</div>
							  </div>
							</div>
						  </div>
					<?php } ?>					
                  </tbody>
                </table>
              </div>
            </div>
          </div>
