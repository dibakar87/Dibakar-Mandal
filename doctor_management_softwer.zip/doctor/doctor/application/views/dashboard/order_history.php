  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> /All Order History list</h1>	
  </div>
  
  	
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">All Order History List!</h6>
            </div>
			
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>S.No</th>
					  <th>Order ID</th>
					  <th>Dr.Name</th>
                      <th>Medical ID</th>                     
                      <th>Action</th>                                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
					  <th>S.No</th>
					  <th>Order ID</th>
					  <th>Dr.Name</th>
                      <th>Medical ID</th>                     
                      <th>Action</th>              
                    </tr>
                  </tfoot>
                  <tbody>
				   
					<?php $i=1; foreach($get_order as $get_doctor_order){ ?>
						<tr>
						  <td>
						  <?php echo $i++ ?></td>						 
						  <td><?php echo $get_doctor_order->ID ; ?></td>
						  <td><?php echo $this->input->get("name"); ?> (<?php echo $get_doctor_order->Doctor_ID ; ?>)</td>
						  <td><?php echo $get_doctor_order->Medical_ID ; ?></td>						  
						 <td><a href="<?php echo base_url()?>dashboard/order_details_edit?DRID=<?php echo $get_doctor_order->Doctor_ID; ?>&name=<?php echo $this->input->get("name"); ?>&OrderID=<?php  echo $get_doctor_order->ID; ?>" title="View"><i class="far fa-eye fa-2x"></i></a></td>
						</tr>										
					<?php } ?>					
                  </tbody>
                </table>
              </div>
            </div>
          </div>

 
      