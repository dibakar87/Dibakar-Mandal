  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> / Doctor</h1>	
  </div>
  
    <!-- add-->
	<div class="container">
		
		  <div class="text-center">
			<h1 class="h4 text-gray-900 mb-4" style="background-color: cornflowerblue;" >Add Doctor!</h1>
		  </div>
		  <form  class="user" onSubmit="return validate();" action="<?php echo base_url(); ?>dashboard/doctor_action" method="post" enctype="multipart/form-data" >
		  
			<div class="form-group row text-center">
			  <div class="col-sm-4">
			  </div>
			  <div class="col-sm-4">
				  <?php if($get_doctor->photo!="" ){?>
					<img  id="viewimg" src="<?php echo base_url();?>assets/img/doctor/<?php echo $get_doctor->photo ?>" alt="Image Preview" style="height: 150px;"  >
				  <?php }else{ ?>
					<img  id="viewimg" src="<?php echo base_url();?>assets/img/No_Image_Available.jpg" alt="Image Preview" style="height: 150px;"  >
				  <?php } ?>				
				<input class="form-control" type="file" onchange="loadFile(event)" id="fileToUpload" name="fileToUpload" autofocus="autofocus" >
				  
				
			  </div>
			  <div class="col-sm-4">
			  </div>
			</div>
		  
			<div class="form-group row">
			  <div class="col-sm-6 mb-3 mb-sm-0">
				<label >Doctor ID</label>
				<input type="text" class="form-control " ID="ShipmentID" Name="ShipmentID"  placeholder="Doctor ID" value="<?php echo $get_doctor->ID; ?>"  readonly>
				
			  </div>
			  <div class="col-sm-6">
				<label >Doctor Name</label>
				<input type="hidden" id="ID" name="ID" value="<?php echo $get_doctor->ID; ?>" >
				<input type="text" class="form-control " id="name" name="name" placeholder="Doctor Name" value="<?php echo $get_doctor->name; ?>" required="required" autofocus="autofocus" >
			  </div>
			</div>
			<div class="form-group">
				<label>Specialists in</label>
			  <input type="text" class="form-control " id="specialists" name="specialists" placeholder="Specialists in" value="<?php echo $get_doctor->specialists; ?>" required="required" autofocus="autofocus" >
			</div>
			<div class="form-group">
				<label>Hospital/Clinic Name</label>
			  <input type="text" class="form-control " id="hospital_clinic_name" name="hospital_clinic_name" placeholder="Hospital/Clinic Name" value="<?php echo $get_doctor->hospital_clinic_name; ?>" required="required" autofocus="autofocus" >
			</div>
			
			<div class="form-group">
				<label>Full Address</label>
			  <input type="text" class="form-control " id="full_address" name="full_address" placeholder="Full Address" value="<?php echo $get_doctor->full_address; ?>" required="required" autofocus="autofocus" >
			</div>
			
			
			
			<div class="form-group row">
			  <div class="col-sm-6 mb-3 mb-sm-0">
				<label >Mobile NO.</label>
				<input type="number" class="form-control " id="mobile_no" name="mobile_no" value="<?php echo $get_doctor->mobile_no; ?>" placeholder="MOBILE NO." required="required" autofocus="autofocus" >
			  </div>
			  <div class="col-sm-6">
				<label >City</label>
				<input type="text" class="form-control " id="city" name="city" value="<?php echo $get_doctor->city; ?>" placeholder="City" required="required" autofocus="autofocus" >
			  </div>
			</div>
			
			<div class="form-group row">
			  <div class="col-sm-6 mb-3 mb-sm-0">
				<label >State</label>
				<input type="text" class="form-control " id="state " name="state" value="<?php echo $get_doctor->state; ?>" placeholder="State" required="required" autofocus="autofocus" >
			  </div>
			  <div class="col-sm-6">
				<label >Assign Medicals (Doctors) </label>
				<!--<input type="text" class="form-control " id="Assign_Doctors " name="Assign_Doctors" value="<?php echo $get_doctor->Assign_Doctors; ?>" placeholder="Assign Medicals (Doctors)" required="required" autofocus="autofocus" >-->
				
				<select class="form-control " name="Assign_Doctors" ID="Assign_Doctors"  required="required" autofocus="autofocus">
				<option>Select Medicals (Doctor)...</option>
				<?php foreach($get_medicals_details as $get_medicals ){ ?>
				<option value="<?php echo $get_medicals->ID; ?>" <?php if($get_medicals->ID == $get_doctor->ID ){ echo"selected";} ?> ><?php echo $get_medicals->Name_of_Medical; ?></option>
				<?php } ?>
			  </select>
			  </div>
			</div>
			
			
			<button type="submit"  class="btn btn-primary btn-user btn-block"><?php if($this->input->get('ID')!=""){ ?> Update<?php }else{ ?>Submit <?php } ?></button>	
					
		  </form>		 
		
	</div>
	
<script>
  var loadFile = function(event){
	  document.getElementById('viewimg').src = URL.createObjectURL(event.target.files[0]);  
  };
</script>