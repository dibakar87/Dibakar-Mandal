  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> /All Medicals list</h1>	
  </div>
  
  	
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">All Medicals List!</h6>
            </div>
			
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>S.No</th>
					  <th>Name of Medical</th>
                      <th>Total Points</th>                     
                      <th>Edit & View</th>                                      
                      <th>Orders View</th>                                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
					  <th>S.No</th>
					  <th>Name of Medical</th>
                      <th>Total Points</th>                     
                      <th>Edit & View</th>                                      
                      <th>Orders View</th>             
                    </tr>
                  </tfoot>
                  <tbody>
				   
					<?php $i=1; foreach($get_medicals_details as $get_medicals){ ?>
						<tr>
						  <td>
						  <?php echo $i++ ?></td>						 
						  <td><?php echo $get_medicals->Name_of_Medical; ?> </td>
						  <td><?php
							$sql="SELECT sum(Point) as point FROM order_master INNER JOIN order_details ON order_master.ID = order_details.OrderID where order_master.Medical_ID='".$get_medicals->ID ."'";	
							$query=$this->db->query($sql);
							$Total_Points=$query->row();
							if($Total_Points->point!=""){ echo $Total_Points->point; }else{ echo '0.00'; }
						   ?></td>						  
						 <td>
							<a href="#" title=" Edit & VIEW" data-toggle="modal" data-target="#doctor_medicals<?php echo $get_medicals->ID; ?>"><i class="far fa-eye fa-2x"></i> </a>
						 </td>	
						 <td>	
							<a href="<?php echo base_url()?>dashboard/doctor_Orders?MID=<?php echo $get_medicals->ID; ?>" title="Orders View" ><i class="fas fa-clipboard-list fa-2x"></i></a>
						 </td>
						</tr>

						 <!-- Logout Modal-->
						  <div class="modal fade" id="doctor_medicals<?php echo $get_medicals->ID; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
							  <div class="modal-content">
								<div class="modal-header">
								  <h5 class="modal-title" id="exampleModalLabel">Medical Details Edit</h5>
								  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">×</span>
								  </button>
								</div>
								<div class="modal-body">								
<form  class="user" onSubmit="return validate();" action="<?php echo base_url(); ?>dashboard/doctor_medicals_action" method="post" enctype="multipart/form-data" >
		  
		  
			<div class="form-group row">
			  <div class="col-sm-6 mb-3 mb-sm-0">
				<label >Name of Medical</label>
				<input type="text" class="form-control " ID="Name_of_Medical" Name="Name_of_Medical"  placeholder="Name of Medical" value="<?php echo $get_medicals->Name_of_Medical; ?>" required="required"  autofocus="autofocus" >
				
			  </div>
			  <div class="col-sm-6">
				<label >Owner Name</label>
				<input type="hidden" id="ID" name="ID" value="<?php echo $get_medicals->ID; ?>" >
				<input type="text" class="form-control " id="Owner_Name" name="Owner_Name" placeholder="Owner Name" value="<?php echo $get_medicals->Owner_Name; ?>" required="required" autofocus="autofocus" >
			  </div>
			</div>
			
			<!-- sudhakar -->
			<div class="form-group">
				<label>License No.</label>
			  <input type="text" class="form-control " id="License_No" name="License_No" placeholder="License No." value="<?php echo $get_medicals->License_No; ?>" required="required" autofocus="autofocus" >
			</div>
			<div class="form-group">
				<label>Near Hostpital/Clinic</label>
			  <input type="text" class="form-control " id="Near_Hostpital_Clinic" name="Near_Hostpital_Clinic" placeholder="Near Hostpital/Clinic" value="<?php echo $get_medicals->Near_Hostpital_Clinic; ?>" required="required" autofocus="autofocus" >
			</div>
			
			<div class="form-group">
				<label>Address</label>
			  <input type="text" class="form-control " id="Address" name="Address" placeholder="Address" value="<?php echo $get_medicals->Address; ?>" required="required" autofocus="autofocus" >
			</div>
			
			
			
			<div class="form-group row">
			  <div class="col-sm-6 mb-3 mb-sm-0">
				<label >City</label>
				<input type="text" class="form-control " id="City" name="City" value="<?php echo $get_medicals->City; ?>" placeholder="City" required="required" autofocus="autofocus" >
			  </div>
			  <div class="col-sm-6">
				<label >Mobile No.</label>
				<input type="number" class="form-control " id="Mobile_No" name="Mobile_No" value="<?php echo $get_medicals->Mobile_No; ?>" placeholder="Mobile No." required="required" autofocus="autofocus" >
			  </div>
			</div>
			
			<div class="form-group row">
			  <div class="col-sm-6 mb-3 mb-sm-0">
				<label >Email ID</label>
				<input type="email" class="form-control " id="Email_ID" name="Email_ID" value="<?php echo $get_medicals->Email_ID; ?>" placeholder="Email ID" required="required" autofocus="autofocus" >
			  </div>
			  <div class="col-sm-6">
				
			  </div>
			</div>
			
			
			<button type="submit"  class="btn btn-primary btn-user btn-block"><?php if($this->input->get('ID')!=""){ ?> Update<?php }else{ ?>Submit <?php } ?></button>	
					
		  </form>
								</div>
								<div class="modal-footer">
								  <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
								</div>
							  </div>
							</div>
						  </div>	
					<?php } ?>					
                  </tbody>
                </table>
              </div>
            </div>
          </div>

 
      