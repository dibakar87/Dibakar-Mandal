  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> /All Medicals list</h1>	
  </div>
  
  	
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">All Medicals List!</h6>
            </div>
			
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>S.No</th>
					  <th>Name of Medical</th>
                      <th>MOBILE NO.</th>                     
                      <th>Edit & VIEW ALL DETAILS</th>                                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
					  <th>S.No</th>
					  <th>Name of Medical</th>
                      <th>MOBILE NO.</th>                      
                      <th>Edit & VIEW ALL DETAILS</th>              
                    </tr>
                  </tfoot>
                  <tbody>
				   
					<?php $i=1; foreach($get_medicals_details as $get_medicals){ ?>
						<tr>
						  <td>
						  <?php echo $i++ ?></td>						 
						  <td><?php echo $get_medicals->Name_of_Medical; ?> </td>
						  <td><?php echo $get_medicals->Mobile_No; ?></td>						  
						 <td><a href="<?php echo base_url()?>dashboard/medicals?ID=<?php echo $get_medicals->ID; ?>" ><i class="far fa-eye"></i>  Edit & VIEW</a></td>
						</tr>										
					<?php } ?>					
                  </tbody>
                </table>
              </div>
            </div>
          </div>

 
      