
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>

<!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> / My Profile</h1>	
  </div>
  
<form  class="user" onSubmit="return validate();" action="<?php echo base_url(); ?>dashboard/my_profile_action" method="post" enctype="multipart/form-data" >  
<table id="customers">
  <tr>
    <th colspan=2 >My Profile</th>     
  </tr>
  <tr>
    <td>  <?php if($get_doctor->photo!="" ){?>
			<img  id="viewimg" src="<?php echo base_url();?>assets/img/doctor/<?php echo $get_doctor->photo ?>" alt="Image Preview" style="height: 150px;"  >
		  <?php }else{ ?>
			<img  id="viewimg" src="<?php echo base_url();?>assets/img/No_Image_Available.jpg" alt="Image Preview" style="height: 150px;"  >
		  <?php } ?>				
				
	</td>     
	<td> 
		<input class="form-control" type="file" onchange="loadFile(event)" id="fileToUpload" name="fileToUpload" autofocus="autofocus" >
	</td>     
  </tr>
  <tr>
    <td>Name</td>
    <td><input type="hidden" id="ID" name="ID" value="<?php echo $get_doctor->ID; ?>" >
		<input type="text" class="form-control " id="name" name="name" placeholder="Doctor Name" value="<?php echo $get_doctor->name; ?>" required="required" autofocus="autofocus" ></td>    
  </tr>
  <tr>
    <td>Specialists in</td>
    <td><input type="text" class="form-control " id="specialists" name="specialists" placeholder="Specialists in" value="<?php echo $get_doctor->specialists; ?>" required="required" autofocus="autofocus" ></td>   
  </tr>
  <tr>
    <td>Hospital/Clinic Name</td>
    <td> <input type="text" class="form-control " id="hospital_clinic_name" name="hospital_clinic_name" placeholder="Hospital/Clinic Name" value="<?php echo $get_doctor->hospital_clinic_name; ?>" required="required" autofocus="autofocus" ></td>    
  </tr>
  <tr>
    <td>Mobile No.</td>
    <td><input type="number" class="form-control " id="mobile_no" name="mobile_no" value="<?php echo $get_doctor->mobile_no; ?>" placeholder="MOBILE NO." required="required" autofocus="autofocus" >
	</td>    
  </tr>

  <tr>
    <td>Full Address</td>
    <td>
	<input type="text" class="form-control " id="full_address" name="full_address" placeholder="Full Address" value="<?php echo $get_doctor->full_address; ?>" required="required" autofocus="autofocus" ></td>    
  </tr>
  <tr>
    <td>City</td>
    <td><input type="text" class="form-control " id="city" name="city" value="<?php echo $get_doctor->city; ?>" placeholder="City" required="required" autofocus="autofocus" ></td>    
  </tr>
  <tr>
    <td>State</td>
    <td><input type="text" class="form-control " id="state " name="state" value="<?php echo $get_doctor->state; ?>" placeholder="State" required="required" autofocus="autofocus" ></td>    
  </tr>
  <tr>
    <td></td>
    <td><button type="submit"  class="btn btn-primary btn-user btn-block"><?php if($this->input->get('ID')!=""){ ?> Update<?php }else{ ?>Submit <?php } ?></button>	</td>    
  </tr>
  
</table>
 </form>	
<script>
  var loadFile = function(event){
	  document.getElementById('viewimg').src = URL.createObjectURL(event.target.files[0]);  
  };
</script>