  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> /My Points</h1>	
  </div>
  
  	
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">My Points Transaction List!</h6>
            </div>
			
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>S.No</th>
					  <th>Details</th>
                      <th>Points</th>
                      <th>Credit/Debit</th>
                      <th>Date</th>                                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
					  <th>S.No</th>
					  <th>Details</th>
                      <th>Points</th>
                      <th>Credit/Debit</th>
                      <th>Date</th>             
                    </tr>
                  </tfoot>
                  <tbody>				   
					<?php $i=1; foreach($my_points as $MP){ ?>
						<tr>
						  <td>
						  <?php echo $i++ ?></td>						 
						  <td>Credit for Purchasing <br><?php
							$sql="select Name_of_Medical from medicals where ID='".$MP->Medical_ID."' ";	
							$query=$this->db->query($sql);
							$Medical=$query->row();

						  echo $Medical->Name_of_Medical; ?> </td>
						  <td><?php echo $MP->Purchasing_Credit ; ?></td>
						  <td>CREDIT</td>
						  <td><?php echo $MP->Order_Date; ?> </td>
						</tr>										
					<?php } ?>	
					<?php $i=$i; foreach($transaction_my_point as $TMP){ ?>
						<tr>
						  <td>
						  <?php echo $i++ ?></td>						 
						  <td><?php echo $TMP->Remakes; ?><br><?php echo $TMP->Transaction_ID; ?> </td>
						  <td><?php echo $TMP->Amount ; ?></td>
						  <td>DEBIT</td>
						  <td><?php echo $TMP->Transaction_Date; ?> </td>
						</tr>										
					<?php } ?>					
                  </tbody>
                </table>
              </div>
            </div>
          </div>

 
      