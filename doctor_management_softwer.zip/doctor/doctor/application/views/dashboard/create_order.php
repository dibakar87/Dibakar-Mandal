  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> / Create Orders</h1>	
  </div>
<script language="JavaScript" type="text/javascript">
function checkDelete(){
    return confirm('Are you sure?');
}
</script> 
    <!-- add-->
	
	<div class="container">	
		  <div class="text-center">
			<h1 class="h4 text-gray-900 mb-4" style="background-color: cornflowerblue;" > Create Orders</h1>
		  </div>
		  <form  class="user" onSubmit="return validate();" action="<?php echo base_url(); ?>dashboard/create_order_action" method="post" enctype="multipart/form-data" >
		  <div class="form-group">
		   <div class="col-sm-12 mb-6 ">
			  <label >CHOOSE MEDICAL (FROM DROP-DOWN WHICH ASSIGN TO DOCTOR) </label>				
				<select class="form-control " name="Medical_ID" ID="Medical_ID"  required="required" autofocus="autofocus">
				<option value="" >Select MEDICAL...</option>
				<?php foreach($get_medicals_details as $get_medicals){ ?>
				<option value="<?php echo $get_medicals->ID; ?>" > <?php echo $get_medicals->Name_of_Medical; ?> </option>
				<?php } ?>
				 </select>
			</div>	
			
			
			<input type="hidden" id="DoctorID" name="DoctorID" value="<?php echo $this->input->get("DRID"); ?>" >
			
		 </div>	
			
			
			<div class="form-group row ">
			  <div class="col-sm-3">
				<label >Product</label>					
				<select class="form-control " name="ProductID[]" ID="ProductID0" onChange="productMethod11(0)"   required="required" autofocus="autofocus">
				<option value="">Select Product...</option>
				<?php foreach($get_products_details as $get_products){ ?>
				<option value="<?php echo $get_products->ID; ?>"> <?php echo $get_products->NAME_OF_THE_PRODUCT; ?> </option>
				<?php } ?>
				</select>
				
			  </div>
			  
			  <div class="col-sm-2">		
				<label >MRP</label>				
				<input type="number" class="form-control " id="MRP0" name="MRP[]" placeholder="MRP" readonly >  
			  </div>
			  
			  <div class="col-sm-2">		
				<label >Quantity</label>				
				<input type="number" class="form-control " id="Quantity0" name="Quantity[]" placeholder="Quantity" onKeyUp="multiply(0)" required="required" autofocus="autofocus"  >  
			  </div>
			  <div class="col-sm-2">
				<label >Amount</label>				
				<input type="number" class="form-control " id="Amount0" name="Amount[]" placeholder="Amount (auto)" required="required" autofocus="autofocus" readonly >
				<input type="hidden" id="Amount_let0"  >
			  </div>
			  <div class="col-sm-2">
				<label >Point</label>				
				<input type="number" class="form-control " id="Point0" name="Point[]" placeholder="Point (auto)" required="required" autofocus="autofocus" readonly >
				<input type="hidden" id="Point_let0"  >
			  </div>
			  
			</div>
			
			<div class="col-sm-12" id="moreFiles"></div>
			<div class="line"></div>
			
			<button type="submit"  class="btn btn-primary btn-user "><?php if($this->input->get('ID')!=""){ ?> Update & Credit<?php }else{ ?>Save & Credit <?php } ?></button>	
			<button type="button" onclick="AddFilesMore()" class="btn btn-success btn-user" >Add More</button>
					
		  </form>		 
		
	</div>
<script>
 	function AddFilesMore(){
		ss=$("#count").val();
		ss=Number(ss)+1;
		$("#count").val(ss);
		var Str='<div class="form-group row "><div class="col-sm-3"><label >Product</label><select class="form-control " onchange="productMethod11('+ss+')" name="ProductID[]" ID="ProductID'+ss+'"  required="required" autofocus="autofocus"><option value="">Select Product...</option><?php foreach($get_products_details as $get_products){ ?><option value="<?php echo $get_products->ID; ?>"> <?php echo $get_products->NAME_OF_THE_PRODUCT; ?> </option><?php } ?></select></div><div class="col-sm-2"><label >MRP</label><input type="number" class="form-control " id="MRP'+ss+'" name="MRP[]" placeholder="MRP" readonly ></div><div class="col-sm-2"><label >Quantity</label><input type="number" class="form-control " id="Quantity'+ss+'" name="Quantity[]" onKeyUp="multiply('+ss+')" placeholder="Quantity" required="required" autofocus="autofocus"  ></div><div class="col-sm-2"><label >Amount</label><input type="number" class="form-control " id="Amount'+ss+'" name="Amount[]" placeholder="Amount (auto)" required="required" autofocus="autofocus" readonly > <input type="hidden" id="Amount_let'+ss+'"  ></div><div class="col-sm-2"><label >Point</label><input type="number" class="form-control " id="Point'+ss+'" name="Point[]" placeholder="Point (auto)" required="required" autofocus="autofocus" readonly><input type="hidden" id="Point_let'+ss+'"  ></div><button type="button"  title="Remove" class="btn btn-danger" style="margin-top: 32px;"  onclick="del_tr(this)"><i class="far fa-times-circle"></i></button> </div>';
		$("#moreFiles").append(Str);
	} 
</script>
<input type="hidden" id="count" value="0">
<script>
	function del_tr(e){   
 	 e.parentNode.parentNode.removeChild(e.parentNode);
	}
</script>


<script>
function multiply(ss) {
  a = Number(document.getElementById('Quantity'+ss).value);
  b = Number(document.getElementById('Amount_let'+ss).value);
  c = Number(document.getElementById('Point_let'+ss).value);
  t = a * b;
  p = a * c;

  document.getElementById('Amount'+ss).value = t;
  document.getElementById('Point'+ss).value = p;
}
</script>
<script>
function productMethod11(ss){
	//alert('00');
	product_id=$("#ProductID"+ss).val();	
	 $.ajax({type: 'POST', url: '<?php echo base_url()?>dashboard/get_product_json?product_id='+product_id, dataType: 'json', 
		success: function(data){	

			
			console.log(data.SQL1);	
			$('#NAME_OF_THE_PRODUCT'+ss).val(data.NAME_OF_THE_PRODUCT);
			$('#Amount'+ss).val(data.PRICE);
			$('#Amount_let'+ss).val(data.PRICE);
			$('#MRP'+ss).val(data.MRP);
			$('#Point'+ss).val(data.Point_isPercentage);
			$('#Point_let'+ss).val(data.Point_isPercentage);
			
		}
    });
}
</script>
