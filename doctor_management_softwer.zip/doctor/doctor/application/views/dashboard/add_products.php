  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-800"><a href="<?php echo base_url(); ?>">Dashboard</a> / Products</h1>	
  </div>
  
    <!--add-->
	<div class="container">
		
		  <div class="text-center">
			<h1 class="h4 text-gray-900 mb-4" style="background-color: cornflowerblue;" >Add Products!</h1>
		  </div>
		  <form  class="user" onSubmit="return validate();" action="<?php echo base_url(); ?>dashboard/products_action" method="post" enctype="multipart/form-data" >
		  
			
		  
			<div class="form-group">
				<label>Name Of The Product</label>
			  <input type="text" class="form-control " id="NAME_OF_THE_PRODUCT" name="NAME_OF_THE_PRODUCT" placeholder="Name Of The Product" value="<?php echo $get_products->NAME_OF_THE_PRODUCT; ?>" required="required" autofocus="autofocus" >
			  <input type="hidden" id="ID" name="ID" value="<?php echo $get_products->ID; ?>" >
			</div>
			<div class="form-group">
				<label>Full Details</label>
			  <input type="text" class="form-control " id="FULL_DETAILS" name="FULL_DETAILS" placeholder="Full Details" value="<?php echo $get_products->FULL_DETAILS; ?>" required="required" autofocus="autofocus" >
			</div>
			
			<div class="form-group row ">
			  <div class="col-sm-3">
			  <label>Price</label>
			  <input type="number" class="form-control " id="PRICE" name="PRICE" placeholder="Price" value="<?php echo $get_products->PRICE; ?>" required="required" autofocus="autofocus" >
			  </div>
			  <div class="col-sm-3">
			   <label>MRP</label>
			  <input type="number" class="form-control " id="MRP" name="MRP" placeholder="MRP" value="<?php echo $get_products->MRP; ?>" required="required" autofocus="autofocus" >
			  </div>
			  <div class="col-sm-2">
			   <label>Point (is Percentage)</label>
			  <input type="number" class="form-control " id="Point_isPercentage" name="Point_isPercentage" placeholder="Point" value="<?php echo $get_products->Point_isPercentage; ?>" required="required" autofocus="autofocus" >
			  </div>
			  <div class="col-sm-4 ">
				 <label>Product Photo</label> 			
				<input class="form-control" type="file" onchange="loadFile(event)" id="fileToUpload" name="fileToUpload" autofocus="autofocus" >
				 <?php if($get_products->Mphoto!="" ){?>
					<img  id="viewimg" src="<?php echo base_url();?>assets/img/Product/<?php echo $get_products->Mphoto ?>" alt="Image Preview" style="height: 150px;"  >
				  <?php }else{ ?>
					<img  id="viewimg" src="<?php echo base_url();?>assets/img/No_Image_Available.jpg" alt="Image Preview" style="height: 150px;"  >
				  <?php } ?>	 
				
			  </div>
			  
			</div>
			
			
			<button type="submit"  class="btn btn-primary btn-user btn-block"><?php if($this->input->get('ID')!=""){ ?> Update<?php }else{ ?>Submit <?php } ?></button>	
					
		  </form>		 
		
	</div>
	
<script>
  var loadFile = function(event){
	  document.getElementById('viewimg').src = URL.createObjectURL(event.target.files[0]);  
  };
</script>