  <style>
	.bg-gradient-color {
		background-color: #dedede;
		background-size: cover;
	}
	.track-h1{
		color: #000000;
		padding: 80px 0px;
		font-weight: 900;
	}
	.bg-welcome-image {
		background: url(http://delivery.newskatadka.com/assets/img/svg/welcome_cat.svg);
		background-position: center;
		background-size: cover;
		background-color: #ff8281;
	}
	.red{color:red;}
  </style>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Track Order</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
   
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url();?>/assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="<?php echo base_url();?>/assets/css/sb-admin-2.min.css" rel="stylesheet">
  </head>
  <body class="bg-gradient-color" >
  
 <div class="container text-center">
    <!-- Outer Row -->
	<div class="col-xl-12 col-lg-12 col-md-9">
		<h1 class="track-h1">TRACK YOUR ORDER</h1>
	
	<form  action="<?php echo base_url(); ?>track/track_order" method="get" enctype="multipart/form-data" >
		<div class="row">
			<div class="col-xl-12 col-lg-12 col-md-9">
			<input type="text" class="form-control "  style="font-size: 1.2rem;" id="shipment_id" name="shipment_id" placeholder="ENTER YOUR SHIPMENT ID "  value="<?php echo $this->input->get('shipment_id'); ?>" required="required" autofocus="autofocus" >
			</div>
		</div>	
		<p>
		</p>
		<div class="row">
			<div class="col-sm-4">
			</div>
			<div class="col-sm-4">
			<button type="submit" style=" font-size: 1.2rem; font-weight: 700; color: #000000;" class="btn btn-warning  btn-user btn-block">SEARCH</button>
			</div>
			<div class="col-sm-4">
			</div>
		</div>
		
	</form>
	</div>
	
	<div>
	<?php if($getAllOrders->DeliveryStatus == "Delivered"){ ?>
	<hr>
		<h2 style="color:#000;">Your Product successfully Delivered.</h2>
	<?php }else{ ?>
		
		<?php
		
		$sql="select Location_Name from location where ID='". $getAllOrders->D_B_Current_location ."' ";	
		$query=$this->db->query($sql);
		$row=$query->row(); 
		?>
	<hr>
	<?php if($this->input->get("shipment_id")!=""){ ?>
		<h2 style="color:#000;">CURRENTLY YOUR SHIPMENT AT <b/><span class="red" ><?php echo $row->Location_Name; ?></span> </b>LOCATION</h2>
		<h2 style="color:#000;"><span style="background-color: #000;padding:2px; border-radius: 9px; color:yellow;">For more detail contact our delivery boy</span><br><br>
			<b>Delivery Boy Name :</b><span class="red" ><?php echo $getAllOrders->FirstName; ?> <?php echo $getAllOrders->LastName; ?></span><br>
			<b>Delivery Boy Number :</b><span class="red" ><?php echo $getAllOrders->MobileNo; ?></span> </h2>
	<?php }} ?>
	
	</div>
    <!-- JavaScript files-->
	
	  <!-- Bootstrap core JavaScript-->
	  <script src="<?php echo base_url();?>/assets/vendor/jquery/jquery.min.js"></script>
	  <script src="<?php echo base_url();?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

	  <!-- Core plugin JavaScript-->
	  <script src="<?php echo base_url();?>/assets/vendor/jquery-easing/jquery.easing.min.js"></script>

	  <!-- Custom scripts for all pages-->
	  <script src="<?php echo base_url();?>/assets/js/sb-admin-2.min.js"></script>
	
	
  </body>
</html> 
