<?php
class Login extends CI_Controller{
	 function __construct() {
        parent::__construct();
		$this->load->model('login_m');
	 }
	public function index(){		
		$data['title']='Welcome Back!';
		$data['page']='home/index';
		$this->load->view("home/index",$data);
	}
	public function admin(){
		if($this->session->userdata("AID")!=""){
			 redirect("dashboard");
		} 
		$data['title']='Admin-login';
		$data['page']='login/login';
		$this->load->view("login/login",$data);
	}
	public function forgot_password(){
		$data['title']='Admin-Forgot password';
		$data['page']='login/forgot_password';
		$this->load->view("login/forgot_password",$data);
	}
	public function register(){
		$data['title']='Admin-register';
		$data['page']='login/register';
		$this->load->view("login/register",$data);
	}
	public function login_check(){
		$Email=$this->input->post('Email');
		$Password=$this->input->post('Password');
		
		if($_POST){			 
			$Email=$this->input->post('Email');
			$Password=$this->input->post('Password');			
			$query=$this->login_m->admin_login($Email,$Password);			
			$query->num_rows() ;			
				if($query->num_rows() > 0){
					$Row=$query->row();					
					 	$this->session->set_userdata("AID",$Row->ID );
						$this->session->set_userdata("Name",$Row->Name );
						$this->session->set_userdata("Type","Admin");	
						$this->session->set_flashdata('SMSG',' Successful Login ');		
				 		redirect('dashboard');
						
				}else{						
						$this->session->set_flashdata('FMSG','LOGIN FAILED, TRY AGAIN!');						
						redirect('login');
				} 	
		}
	}
	public function logout(){		
		$this->session->sess_destroy();
		redirect("login");		
	}  
	
	public function logout_admin_for_db(){		
		$this->session->set_userdata("DID","" );
		$this->session->set_userdata("DBN","" );
		$this->session->set_userdata("Status","" );
		$this->session->set_userdata("Type","Admin");	
		redirect("dashboard");
	}  
		
	/* =============[doctor]================== */
	public function chnage(){
		if($this->session->userdata("DID")!=""){
			 redirect("dashboard");
		}  
		$data['title']='chnage number';
		$data['page']='login/chnage';
		$this->load->view("login/chnage",$data);
	}
	public function doctor(){
		if($this->session->userdata("DID")!=""){
			 redirect("dashboard");
		}  
		$data['title']='Doctor';
		$data['page']='login/doctor';
		$this->load->view("login/doctor",$data);
	}
	public function process_mobile_verification(){			
	
		switch ($_POST["action"]) {
            case "send_otp":
			$mobile=$this->input->post('mobile_number');
			
			$result="No";
			$IsRows= $this->login_m->IsUserAval($mobile);
			if($IsRows>0){
			$result="yes";
			}
			setcookie("New_User", $result, time() + (86400 * 30), "/"); 
				
			if($result=="yes"){
				/* ======[Auto Genaret otp]========== */
				$otp = rand(100000, 999999);			
			
				$this->session->set_userdata("session_otp",$otp);	
				setcookie("Mobile", $mobile, time() + (86400 * 30), "/"); 
			
				$this->load->model('Email_m');
				$this->Email_m->OTP($otp,$mobile);
				/* =======[Auto Genaret otp End]======= */
				echo json_encode(array("type"=>"success", "message"=>"OTP sent Successfully.")); 
			}else{
				echo json_encode(array("type"=>"error", "message"=>"Your Number  not registered!")); 	
			}
			break;
			
			case "verify_otp":
			$otp = $_POST['otp'];
			$session_otp=$this->session->userdata("session_otp");
				if ($otp == $session_otp) {
					setcookie("VeriFied", "Yes", time() + (86400 * 30), "/"); 
					unset($session_otp);
					echo json_encode(array("type"=>"success", "message"=>"Your mobile number is verified!","mobile"=>$_COOKIE[Mobile] ));					
				} else {
					echo json_encode(array("type"=>"error", "message"=>"Mobile number verification failed", "mobile"=>""));
				}
			break;
		}
		
	}	
	public function IsUserAval($Mobile){
		//$Mobile=$_COOKIE[Mobile];
		$result="No";
		$query= $this->login_m->IsUserAval($Mobile);
		$query->num_rows() ;
		if($query->num_rows() > 0){
		$result="yes";
		$Row=$query->row();
			$this->session->set_userdata("DRID",$Row->ID );
			$this->session->set_userdata("Name",$Row->name );
			$this->session->set_userdata("Doctor_photo",$Row->photo );
			$this->session->set_userdata("Type","Doctor");	
		
		}	
		

		
		echo json_encode(array("user"=>"$result", "message"=>"Your mobile number is verified!"));
		
	}
	/* =============[doctor End]================== */
		
}