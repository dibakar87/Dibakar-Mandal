<?php
class Dashboard extends CI_Controller{
	 function __construct() {
        parent::__construct();
		$this->load->model('dashboard_m');	
		$this->load->model('login_m');	
		//$this->load->model('Email_m');	
		$this->login_m->IsLogin();	  
	 }
	public function index(){	
		//$data['getAllUsers']= $this->dashboard_m->getAllUsers();
		//$data['getAllContest']= $this->dashboard_m->getAllContest();
		if($this->session->userdata("Type")=="Admin"){
		//$data['shipment_list']= $this->dashboard_m->get_shipment_list_details();		
		$data['title']='dashboard';
		$data['page']='dashboard/index';
		}else{
		/* $data['get_RPQC']= $this->dashboard_m->get_RPQC();
		$data['shipment_list']= $this->dashboard_m->get_shipment_list_details_db();
		$data['title']='dashboard';
		$data['page']='dashboard/all_shipment'; */
		
		$data['title']='dashboard';
		$data['page']='dashboard/index';
		}
		
		$this->load->view("layout/index",$data);
	}
	
	/* ========================ADMIN========================= */
	/* ========================Doctor========================= */
	public function doctor(){
		$ID=$this->input->get('DRID');
		if($ID!=""){
			$data['get_doctor']= $this->dashboard_m->get_doctor($ID);
		}
		$data['get_medicals_details']= $this->dashboard_m->get_medicals_details();		
		$data['title']='add doctor';
		$data['page']='dashboard/add_doctor';
		$this->load->view("layout/index",$data);
	}
	public function wallet(){
		$ID=$this->input->get('ID');		
		$data['transaction']= $this->dashboard_m->get_transaction($ID);		
		$data['get_transaction_details']= $this->dashboard_m->get_transaction_details();
		
		$data['title']='credit debit for doctor';
		$data['page']='dashboard/credit_debit_for_doctor';
		$this->load->view("layout/index",$data);
	}
	public function wallet_action(){
		$ID=$this->input->post('ID');		
		$this->dashboard_m->wallet_action($ID);	
		if($ID!=""){
			$this->session->set_flashdata('SMSG','Update successful.');
		}else{
			$this->session->set_flashdata('SMSG','Insert successful.');
		}	
		redirect('dashboard/doctor_list');	
	}
	public function order_history(){
		$Doctor_ID=$this->input->get('DRID');		
		$data['get_order']= $this->dashboard_m->get_order($Doctor_ID);		
		//$data['get_order_details']= $this->dashboard_m->get_order_details($Doctor_ID);
		
		$data['title']='Orders History';
		$data['page']='dashboard/order_history';
		$this->load->view("layout/index",$data);
	}
	public function order_details_edit(){
		$Doctor_ID=$this->input->get('DRID');		
		//$data['get_order']= $this->dashboard_m->get_order($Doctor_ID);	
		
		$data['get_medicals_details']= $this->dashboard_m->get_medicals_details();	
		$data['get_products_details']= $this->dashboard_m->get_products_details();	
		
		$data['get_order_details']= $this->dashboard_m->get_order_details($Doctor_ID);
		
		$data['title']='Orders Edit';
		$data['page']='dashboard/order_details_edit';
		$this->load->view("layout/index",$data);
	}
	public function create_order_edit_action(){
		
		$OMID=$this->input->post('OMID');		
		$ODID=$this->input->post('ODID');		
		$DoctorName=$this->input->post('DoctorName');		
		$Medical_ID=$this->input->post('Medical_ID');
		$DoctorID=$this->input->post('DoctorID');
		
		
		$ProductID=$this->input->post('ProductID');
		$Quantity=$this->input->post('Quantity');
		$MRP=$this->input->post('MRP');
		$Amount=$this->input->post('Amount');
		$Point=$this->input->post('Point');	
		$OrderID=$OMID;	
		
		$this->dashboard_m->create_order_edit($OMID,$Medical_ID,$DoctorID);	
		$this->dashboard_m->create_order_action_edit($ODID,$OrderID,$ProductID,$MRP,$Quantity,$Amount,$Point);
 
		if($ODID!=""){
			$this->session->set_flashdata('SMSG','Update successful.');
		}else{
			$this->session->set_flashdata('SMSG','Insert successful.');
		}	
		redirect('dashboard/order_details_edit?DRID='.$DoctorID.'&name='.$DoctorName.'&OrderID='.$OMID);	
	}
	public function doctor_list(){		
		$data['get_doctor_details']= $this->dashboard_m->get_doctor_details();		
		$data['title']='list doctor';
		$data['page']='dashboard/doctor_list';
		$this->load->view("layout/index",$data);
	}
	public function create_order(){		
		$ID=$this->input->get('DRID');		
		$data['get_doctor']= $this->dashboard_m->get_doctor($ID);	
		
		$data['get_medicals_details']= $this->dashboard_m->get_medicals_details();	
		$data['get_products_details']= $this->dashboard_m->get_products_details();	
		
		$data['title']='Create doctors';
		$data['page']='dashboard/create_order';
		$this->load->view("layout/index",$data);
	}
	public function create_order_action(){	
		//$ID=$this->input->post('ID');		
		$Medical_ID=$this->input->post('Medical_ID');
		$DoctorID=$this->input->post('DoctorID');
		
		
		$ProductID=$this->input->post('ProductID');
		$Quantity=$this->input->post('Quantity');
		$MRP=$this->input->post('MRP');
		$Amount=$this->input->post('Amount');
		$Point=$this->input->post('Point');
		
		$OrderID=$this->dashboard_m->create_order($Medical_ID,$DoctorID);	
		foreach( $ProductID as $key => $n ){
			
			/* if($ProductID[$key]==""){
				$ExtraKey=$ExtraKey+1;
			} 
			$myKey=$ExtraKey+$key;*/
			
			$this->dashboard_m->create_order_action($OrderID,$ProductID[$key],$MRP[$key],$Quantity[$key],$Amount[$key],$Point[$key]);
		}
			
		$this->session->set_flashdata('SMSG','Insert successful.');		
		redirect('dashboard/doctor_list');	
	}
	
	
	
	public function get_product_json(){
		$id=$this->input->get('product_id');		
		if($id!=""){			
			$sql1="SELECT * FROM `products` WHERE `ID`='".$id."'";
			$query1=$this->db->query($sql1);
			$getPro=$query1->row(); 
			echo json_encode( array( 'NAME_OF_THE_PRODUCT' =>$getPro->NAME_OF_THE_PRODUCT,'PRICE' =>$getPro->PRICE,'MRP' =>$getPro->MRP,'Point_isPercentage' =>$getPro->Point_isPercentage,'SQL1'=>$sql1));			
		}
	}
	
	
	
	public function doctor_action(){		
		$target_dir = "assets/img/doctor/";
		$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		
		// Allow certain file formats	
		if($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "gif"){	
			$myImg = "ok";			
		}else{
			$this->session->set_flashdata('FMSG','Sorry, only JPG, JPEG, PNG & GIF files are allowed.');
		}
		
		// Check file size
		if ($_FILES["fileToUpload"]["size"] > 200000) {		  
			$this->session->set_flashdata('FMSG','Sorry, your file is too large.');		 
		}else{
			$uploadsize ="ok";
		}
		
		// if everything is ok, try to upload file
		if($myImg=="ok" && $uploadsize=="ok" ){			
			$Photo=date("Y-m-d-H-i-s").".".$imageFileType; 
			move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],  $target_dir .$Photo);
		} 	
		if($imageFileType==""){
			$Photo="";
		} 
		
		$ID=$this->input->post('ID');		
		$this->dashboard_m->new_doctor_action($ID,$Photo);
		
		if($ID!=""){
			$this->session->set_flashdata('SMSG','Update successful.');
		}else{
			$this->session->set_flashdata('SMSG','Insert successful.');
		}
		redirect('dashboard/doctor_list');
	}
	/* ========================Doctor End========================= */
	/* ========================medicals========================= */
	public function medicals(){
		$ID=$this->input->get('ID');
		if($ID!=""){
			$data['get_medicals']= $this->dashboard_m->get_medicals($ID);
		}
		$data['title']='add medicals';
		$data['page']='dashboard/add_medicals';
		$this->load->view("layout/index",$data);
	}
	public function medicals_list(){		
		$data['get_medicals_details']= $this->dashboard_m->get_medicals_details();		
		$data['title']='list medicals';
		$data['page']='dashboard/medicals_list';
		$this->load->view("layout/index",$data);
	}
	
	public function medicals_action(){		
		$ID=$this->input->post('ID');		
		$this->dashboard_m->new_medicals_action($ID);
		
		if($ID!=""){
			$this->session->set_flashdata('SMSG','Update successful.');
		}else{
			$this->session->set_flashdata('SMSG','Insert successful.');
		}
		redirect('dashboard/medicals_list');
	}
	/* ========================medicals End========================= */
	/* ========================PRODUCTS========================= */
	public function products(){
		$ID=$this->input->get('ID');
		if($ID!=""){
			$data['get_products']= $this->dashboard_m->get_products($ID);
		}
		$data['title']='add products';
		$data['page']='dashboard/add_products';
		$this->load->view("layout/index",$data);
	}
	public function products_list(){		
		$data['get_products_details']= $this->dashboard_m->get_products_details();		
		$data['title']='list products';
		$data['page']='dashboard/products_list';
		$this->load->view("layout/index",$data);
	}
	
	public function products_action(){		
		$target_dir = "assets/img/Product/";
		$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		
		// Allow certain file formats	
		if($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "gif"){	
			$myImg = "ok";			
		}else{
			$this->session->set_flashdata('FMSG','Sorry, only JPG, JPEG, PNG & GIF files are allowed.');
		}
		
		// Check file size
		if ($_FILES["fileToUpload"]["size"] > 200000) {		  
			$this->session->set_flashdata('FMSG','Sorry, your file is too large.');		 
		}else{
			$uploadsize ="ok";
		}
		
		// if everything is ok, try to upload file
		if($myImg=="ok" && $uploadsize=="ok" ){			
			$Photo=date("Y-m-d-H-i-s").".".$imageFileType; 
			move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],  $target_dir .$Photo);
		} 	
		if($imageFileType==""){
			$Photo="";
		} 
		
		$ID=$this->input->post('ID');		
		$this->dashboard_m->new_products_action($ID,$Photo);
		
		if($ID!=""){
			$this->session->set_flashdata('SMSG','Update successful.');
		}else{
			$this->session->set_flashdata('SMSG','Insert successful.');
		}
		redirect('dashboard/products_list');
	}
	/* ========================PRODUCTS End========================= */
	/* ========================ADMIN END========================= */
	
	/* ========================DOCTOR ========================= */
	/* ========================my_profile ========================= */
	public function my_profile(){
		$ID=$this->session->userdata("DRID");		
		$data['get_doctor']= $this->dashboard_m->get_doctor($ID);
				
		$data['title']='My Profile';
		$data['page']='dashboard/my_profile';
		$this->load->view("layout/index",$data);
	}
	public function my_profile_action(){		
		$target_dir = "assets/img/doctor/";
		$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		
		// Allow certain file formats	
		if($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "gif"){	
			$myImg = "ok";			
		}else{
			$this->session->set_flashdata('FMSG','Sorry, only JPG, JPEG, PNG & GIF files are allowed.');
		}
		
		// Check file size
		if ($_FILES["fileToUpload"]["size"] > 200000) {		  
			$this->session->set_flashdata('FMSG','Sorry, your file is too large.');		 
		}else{
			$uploadsize ="ok";
		}
		
		// if everything is ok, try to upload file
		if($myImg=="ok" && $uploadsize=="ok" ){			
			$Photo=date("Y-m-d-H-i-s").".".$imageFileType; 
			move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],  $target_dir .$Photo);
		} 	
		if($imageFileType==""){
			$Photo="";
		} 
		
		$ID=$this->input->post('ID');		
		$this->dashboard_m->new_doctor_action($ID,$Photo);
		
		if($ID!=""){
			$this->session->set_flashdata('SMSG','Update successful.');
		}else{
			$this->session->set_flashdata('SMSG','Insert successful.');
		}
		redirect('dashboard/my_profile');
	}
	
	/* ========================my_profile end ========================= */
	/* ========================doctor_view_medicals ========================= */
	public function doctor_medicals(){
		$ID=$this->session->userdata("DRID");		
		$data['get_doctor']= $this->dashboard_m->get_doctor($ID);
		$data['get_medicals_details']= $this->dashboard_m->get_medicals_details();			
		$data['title']='medicals';
		$data['page']='dashboard/doctor_view_medicals';
		$this->load->view("layout/index",$data);
	}
	
	public function doctor_medicals_action(){		
		$ID=$this->input->post('ID');		
		$this->dashboard_m->new_medicals_action($ID);
		
		if($ID!=""){
			$this->session->set_flashdata('SMSG','Update successful.');
		}else{
			$this->session->set_flashdata('SMSG','Insert successful.');
		}
		redirect('dashboard/doctor_medicals');
	}
	/* ========================doctor_view_medicals end ========================= */
	/* ========================doctor_Order Orders ========================= */
	public function doctor_Orders(){
		$ID=$this->session->userdata("DRID");		
		$MID=$this->input->get("MID");		
		//$data['get_doctor']= $this->dashboard_m->get_doctor($ID);
		//$data['get_products_details']= $this->dashboard_m->get_products_details();		
		$data['get_medicals_and_doc_order_details']= $this->dashboard_m->get_medicals_and_doc_order_details($ID,$MID);	
		$data['title']='medicals';
		$data['page']='dashboard/doctor_orders';
		$this->load->view("layout/index",$data);
	}
	
	
	/* ========================doctor_orders end ========================= */
	
	/* ========================doctor_products_list  ========================= */
	public function doctor_products(){
		//$ID=$this->session->userdata("DRID");	
		$data['get_products_details']= $this->dashboard_m->get_products_details();			
		$data['title']='Products List';
		$data['page']='dashboard/doctor_products_list';
		$this->load->view("layout/index",$data);
	}
	
	
	/* ========================doctor_products_list end ========================= */
	/* ========================my_points  ========================= */
	public function my_points(){
		$ID=$this->session->userdata("DRID");	
		$data['my_points']= $this->dashboard_m->my_points($ID);			
		$data['transaction_my_point']= $this->dashboard_m->transaction_my_point($ID);			
		$data['title']='my points';
		$data['page']='dashboard/my_points';
		$this->load->view("layout/index",$data);
	}
	
	
	/* ========================my_points end ========================= */
	/* ========================DOCTOR END========================= */
}
?>