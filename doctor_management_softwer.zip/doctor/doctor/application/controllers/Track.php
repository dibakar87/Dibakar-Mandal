<?php
class Track extends CI_Controller{
	 function __construct() {
        parent::__construct();
		$this->load->model('Track_m');	  
	 }
	public function index(){		
		$data['title']='Track Order';
		$data['page']='track_order/index';
		$this->load->view("track_order/index",$data);
	}
	public function track_order(){		
		$data['getAllOrders']= $this->Track_m->getAllOrders();
		$data['title']='Track Order';
		$data['page']='track_order/index';
		$this->load->view("track_order/index",$data);
	}
}
?>