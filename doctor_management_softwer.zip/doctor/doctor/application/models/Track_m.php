<?php
class Track_m extends CI_Model{	
	
	public function getAllOrders(){	
		$dbid=$this->db->conn_id;		
		
		$sql="SELECT delivery_boy_registration.D_B_Current_location ,delivery_boy_registration.FirstName ,delivery_boy_registration.LastName ,delivery_boy_registration.MobileNo , shipment.DeliveryStatus FROM delivery_boy_registration INNER JOIN shipment  ON delivery_boy_registration.ID=shipment.DBID WHERE shipment.ShipmentID LIKE '".mysqli_real_escape_string( $dbid ,$this->input->get('shipment_id'))."' ";	
		$query=$this->db->query($sql);
		return $query->row();
	}
	
}
?>