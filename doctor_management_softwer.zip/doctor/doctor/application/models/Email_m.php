<?php
class Email_m extends CI_Model{
	public function OTP($otp,$mobile){
		$mobileNO=$mobile;
		
		$mobileMsg = "Your One Time Password is " . $otp;
	 $this->mySMS($mobileNO,$mobileMsg); 	
	}
	public function mySMS($mobileNO,$mobileMsg){
		
		if($mobileNO!=""){			
			file_get_contents("http://my.msgwow.com/api/sendhttp.php?authkey=318420A08N1sJJ7r5ecceaa2P1&mobiles=91".$mobileNO."&message=".$mobileMsg."&sender=DOCTOR&route=4&country=0");
			
		}	
	}
	/* ====[SMS-END]=== */
	
	
	
	
	/* ============================RegisteredNotification========================= */
	public function RegisteredNotification($Mobile,$Email){
		$dbid=$this->db->conn_id;	
		$sql="select * from delivery_boy_registration where EmailID='".mysqli_real_escape_string( $dbid , $Email)."'";
		
		$query=$this->db->query($sql);
		$user=$query->row();
		
		$p=$user->Password;
	 	$phone=$user->MobileNo;
	 	$email=$user->EmailID;
		$fnane=$user->FirstName;
		$lname=$user->LastName;
		
		$subject="Registered Successfully - DELIVERY";
		$adminSubject="Registered Successfully";
		$emailMessage="Your Registered Successfully. <br>User Name :".$email." <br> Password Is : ".$p;		
		$AdminEmailMessage="Someone Registered  - Delivery boy name:".$fnane." ".$lname."<br>Email ID:". $email;
		
	
	 $this->MyMail($email,$subject,$emailMessage); 
	 $this->MyMail("admin",$adminSubject,$AdminEmailMessage); 
	}
	/* ============================RegisteredNotification End========================= */
	
	public function MyMail($toMail,$subject,$msg ){
		 if($msg!=""){
			 
			//============= smtp2go============ 
			
				$config['protocol']    = 'smtp';
				$config['smtp_host']    = 'ns7.webeyesoft.com';
				$config['smtp_port']    = '587';
				$config['smtp_timeout'] = '7';
				$config['smtp_user']    = 'info@newskatadka.com';
				$config['smtp_pass']    = 'Admin@!_123';
				$config['charset']    = 'utf-8';
				$config['newline']    = "\r\n";
				$config['mailtype'] = 'html'; // or html
				$config['validation'] = TRUE; // bool whether to validate email or not       
				$this->load->library('email');
				$this->email->initialize($config);

				$this->email->from('info@newskatadka.com', 'DELIVERY');
				if($toMail=="admin"){
					$toMail="dibakarmandal87@gmail.com ";
				}
				
				$this->email->to($toMail); 

				$this->email->subject($subject);
				$this->email->message($msg);  

				$this->email->send();     
				 
			 }
			
	}
}