<?php
class Login_m extends CI_Model{
	/* admin database name  admin_login*/
	/* 	ID	Name	Email	Password	DateAndTime	Status */

	public function admin_login($Email,$Password){
		$dbid=$this->db->conn_id;
		$sql="select* from admin_login where Email='".mysqli_real_escape_string( $dbid ,$Email)."' and Password='".mysqli_real_escape_string( $dbid ,$Password)."'";	
		$query=$this->db->query($sql);
		return $query; 
	}
	public function IsUserAval($mobile_no){
		$dbid=$this->db->conn_id;
		$sql="select* from doctor where mobile_no='".mysqli_real_escape_string( $dbid ,$mobile_no)."' ";	
		$query=$this->db->query($sql);
		return $query; 
	}
	
	public function IsLogin(){
		//if(($this->session->userdata("AID")=="") || ($this->session->userdata("DID")=="")){ 			
		if($this->session->userdata("Type")==""){ 			
			redirect("login");					
		} 
	}
}