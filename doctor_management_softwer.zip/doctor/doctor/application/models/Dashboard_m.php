<?php
class Dashboard_m extends CI_Model{	
	
	public function getAllUsers(){		
		$sql="SELECT COUNT(ID) as user FROM delivery_boy_registration ";	
		$query=$this->db->query($sql);
		return $query->row();
	}
	public function getAllContest(){		
		$sql="SELECT COUNT(ID) as Contest FROM admin_login ;";	
		$query=$this->db->query($sql);
		return $query->row();
	}
	


	/* ===[ID name photo specialists hospital_clinic_name mobile_no	full_address city state	Assign_Doctors date_time status ]================= */
	public function new_doctor_action($ID,$photo){
		$dbid=$this->db->conn_id;		
		$sql=" `doctor` SET 
		`name` = '".mysqli_real_escape_string( $dbid ,$this->input->post('name'))."',
		`specialists` = '".mysqli_real_escape_string( $dbid ,$this->input->post('specialists'))."',
		`hospital_clinic_name` = '".mysqli_real_escape_string( $dbid ,$this->input->post('hospital_clinic_name'))."',
		`mobile_no` = '".mysqli_real_escape_string( $dbid ,$this->input->post('mobile_no'))."',
		`full_address` = '".mysqli_real_escape_string( $dbid ,$this->input->post('full_address'))."',
		`city` = '".mysqli_real_escape_string( $dbid ,$this->input->post('city'))."',
		`state` = '".mysqli_real_escape_string( $dbid ,$this->input->post('state'))."',
		`Assign_Doctors` = '".mysqli_real_escape_string( $dbid ,$this->input->post('Assign_Doctors'))."',";
			if($photo!=""){
				$sql.="`photo` = '".mysqli_real_escape_string( $dbid ,$photo )."',	";
			}			  		
		$sql.="	`status` = 'Active'";	

		if($ID==""){
			$sql="Insert into ".$sql;			
		}else{
			$sql="UPDATE ".$sql." where ID='".$ID."'";			
		}
		
		$this->db->query($sql);
		
	}
	public function get_doctor_details(){		
		$sql="select * from doctor ";	
		$query=$this->db->query($sql);
		return $query->result();
	}
	public function get_doctor($ID){		
		$sql="select * from doctor where ID='".$ID."' ";	
		$query=$this->db->query($sql);
		return $query->row();
	}
	/* ==============[end ]================== */
	

	/* ===[ID Name_of_Medical Owner_Name License_No Near_Hostpital_Clinic Address City Mobile_No Email_ID Status]=== */
	public function new_medicals_action($ID){
		$dbid=$this->db->conn_id;		
		$sql=" `medicals` SET 
		`Name_of_Medical` = '".mysqli_real_escape_string( $dbid ,$this->input->post('Name_of_Medical'))."',
		`Owner_Name` = '".mysqli_real_escape_string( $dbid ,$this->input->post('Owner_Name'))."',
		`License_No` = '".mysqli_real_escape_string( $dbid ,$this->input->post('License_No'))."',
		`Near_Hostpital_Clinic` = '".mysqli_real_escape_string( $dbid ,$this->input->post('Near_Hostpital_Clinic'))."',
		`Address` = '".mysqli_real_escape_string( $dbid ,$this->input->post('Address'))."',
		`City` = '".mysqli_real_escape_string( $dbid ,$this->input->post('City'))."',
		`Mobile_No` = '".mysqli_real_escape_string( $dbid ,$this->input->post('Mobile_No'))."',
		`Email_ID` = '".mysqli_real_escape_string( $dbid ,$this->input->post('Email_ID'))."',
		`status` = 'Active'";	

		if($ID==""){
			$sql="Insert into ".$sql;			
		}else{
			$sql="UPDATE ".$sql." where ID='".$ID."'";			
		}
		
		$this->db->query($sql);
		
	}
	public function get_medicals_details(){		
		$sql="select * from medicals ";	
		$query=$this->db->query($sql);
		return $query->result();
	}
	public function get_medicals($ID){		
		$sql="select * from medicals where ID='".$ID."' ";	
		$query=$this->db->query($sql);
		return $query->row();
	}
	/* ==============[end ]================== */

	/* ===[ID	NAME_OF_THE_PRODUCT	FULL_DETAILS	PRICE	Mphoto	Status]=== */
	public function new_products_action($ID,$photo){
		$dbid=$this->db->conn_id;		
		$sql=" `products` SET 
		`NAME_OF_THE_PRODUCT` = '".mysqli_real_escape_string( $dbid ,$this->input->post('NAME_OF_THE_PRODUCT'))."',
		`FULL_DETAILS` = '".mysqli_real_escape_string( $dbid ,$this->input->post('FULL_DETAILS'))."',
		`PRICE` = '".mysqli_real_escape_string( $dbid ,$this->input->post('PRICE'))."',
		`MRP` = '".mysqli_real_escape_string( $dbid ,$this->input->post('MRP'))."',
		`Point_isPercentage` = '".mysqli_real_escape_string( $dbid ,$this->input->post('Point_isPercentage'))."',";
			if($photo!=""){
				$sql.="`Mphoto` = '".mysqli_real_escape_string( $dbid ,$photo )."',	";
			}			  		
		$sql.="	`Status` = 'Active'";	

		if($ID==""){
			$sql="Insert into ".$sql;			
		}else{
			$sql="UPDATE ".$sql." where ID='".$ID."'";			
		}
		
		$this->db->query($sql);
		
	}
	public function get_products_details(){		
		$sql="select * from products ";	
		$query=$this->db->query($sql);
		return $query->result();
	}
	public function get_products($ID){		
		$sql="select * from products where ID='".$ID."' ";	
		$query=$this->db->query($sql);
		return $query->row();
	}
	/* ==============[end ]================== */
	/* ==============[create_order_action ]================== */
	public function create_order($Medical_ID,$DoctorID){
		$dbid=$this->db->conn_id;	
		/* ===[ID	Doctor_ID	Medical_ID	Order_Date]=== */
		$sql="Insert into  `order_master` SET 
		`Doctor_ID` = '".mysqli_real_escape_string( $dbid ,$DoctorID)."',
		`Medical_ID` = '".mysqli_real_escape_string( $dbid ,$Medical_ID)."',
		`Order_Date` = '".mysqli_real_escape_string( $dbid ,date("Y-m-d"))."'";
		$this->db->query($sql);
		return $insert_id = $this->db->insert_id(); 		
	}
	public function create_order_action($OrderID,$ProductID,$MRP,$Quantity,$Amount,$Point){
		$dbid=$this->db->conn_id;		
		/* ==[OrderID	ProductID	Quantity	Amount	Point	Status]== */
		$sql="Insert into  `order_details` SET 
		`OrderID` = '".mysqli_real_escape_string( $dbid ,$OrderID)."',
		`ProductID` = '".mysqli_real_escape_string( $dbid ,$ProductID)."',
		`MRP` = '".mysqli_real_escape_string( $dbid ,$MRP)."',
		`Quantity` = '".mysqli_real_escape_string( $dbid ,$Quantity)."',
		`Amount` = '".mysqli_real_escape_string( $dbid ,$Amount)."',
		`Point` = '".mysqli_real_escape_string( $dbid ,$Point)."',		
		`status` = 'Active'";
		$this->db->query($sql);
		
	}
	/* ---------------------Edit---------------------------- */
	public function create_order_edit($ID,$Medical_ID,$DoctorID){
		$dbid=$this->db->conn_id;	
		/* ===[ID	Doctor_ID	Medical_ID	Order_Date]=== */
		$sql="UPDATE `order_master` SET 
		`Doctor_ID` = '".mysqli_real_escape_string( $dbid ,$DoctorID)."',
		`Medical_ID` = '".mysqli_real_escape_string( $dbid ,$Medical_ID)."' where ID='".$ID."'";
		$this->db->query($sql);
				
	}
	public function create_order_action_edit($ID,$OrderID,$ProductID,$MRP,$Quantity,$Amount,$Point){
		$dbid=$this->db->conn_id;		
		/* ==[OrderID	ProductID	Quantity	Amount	Point	Status]== */
		$sql="UPDATE `order_details` SET 
		`OrderID` = '".mysqli_real_escape_string( $dbid ,$OrderID)."',
		`ProductID` = '".mysqli_real_escape_string( $dbid ,$ProductID)."',
		`MRP` = '".mysqli_real_escape_string( $dbid ,$MRP)."',
		`Quantity` = '".mysqli_real_escape_string( $dbid ,$Quantity)."',
		`Amount` = '".mysqli_real_escape_string( $dbid ,$Amount)."',
		`Point` = '".mysqli_real_escape_string( $dbid ,$Point)."',		
		`status` = 'Active' where ID='".$ID."'";
		$this->db->query($sql);
		
	}
	
	public function get_order_details($Doctor_ID){		
		$sql="SELECT order_master.*, order_master.ID as OMID,order_details.ID as ODID, order_details.* FROM order_master INNER JOIN order_details ON order_master.ID = order_details.OrderID where order_master.Doctor_ID='".$Doctor_ID."'";	
		$query=$this->db->query($sql);
		return $query->result();
	}
	public function get_order($Doctor_ID){		
		$sql="SELECT * FROM order_master where Doctor_ID='".$Doctor_ID."'";	
		$query=$this->db->query($sql);
		return $query->result();
	}
	
	/* ==============[create_order_action end ]================== */
	/* ==============[ID	Doctor_ID	Amount	Transaction_ID	Remakes	Transaction_Type	Transaction_Date  ]================== */
	public function wallet_action($ID){
		$dbid=$this->db->conn_id;		
		$sql=" `transaction` SET 
		`Doctor_ID` = '".mysqli_real_escape_string( $dbid ,$this->input->post('Doctor_ID'))."',
		`Amount` = '".mysqli_real_escape_string( $dbid ,$this->input->post('AMOUNT'))."',
		`Transaction_ID` = '".mysqli_real_escape_string( $dbid ,$this->input->post('Transaction_ID'))."',
		`Remakes` = '".mysqli_real_escape_string( $dbid ,$this->input->post('REMARK'))."',
		`Transaction_Type` = '".mysqli_real_escape_string( $dbid ,$this->input->post('type_c_d'))."',		
		`Transaction_Date` = '".date("Y-m-d")."'";	

		if($ID==""){
			$sql="Insert into ".$sql;			
		}else{
			$sql="UPDATE ".$sql." where ID='".$ID."'";			
		}
		
		$this->db->query($sql);
		
	}
	
	public function get_transaction_details(){		
		$sql="select * from transaction ";	
		$query=$this->db->query($sql);
		return $query->result();
	}
	public function get_transaction($ID){		
		$sql="select * from transaction where ID='".$ID."' ";	
		$query=$this->db->query($sql);
		return $query->row();
	}
	/* ==============[wallet_action end ]================== */
	public function get_medicals_and_doc_order_details($Doctor_ID,$MID){		
		$sql="SELECT order_master.*, order_master.ID as OMID,order_details.ID as ODID, order_details.* FROM order_master INNER JOIN order_details ON order_master.ID = order_details.OrderID where order_master.Medical_ID='".$MID."' and order_master.Doctor_ID='".$Doctor_ID."'";	
		$query=$this->db->query($sql);
		return $query->result();
	}
	
	public function my_points($Doctor_ID){		
		$sql="SELECT sum(`order_details`.`Point`) as Purchasing_Credit, order_master.*  FROM order_master INNER JOIN order_details ON order_master.ID = order_details.OrderID where order_master.Doctor_ID='".$Doctor_ID."'";	
		$query=$this->db->query($sql);
		return $query->result();
	}
	public function transaction_my_point($Doctor_ID){		
		$sql="select * from transaction where Doctor_ID='".$Doctor_ID."'";	
		$query=$this->db->query($sql);
		return $query->result();
	}
}